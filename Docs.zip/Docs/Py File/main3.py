#C:\Users\kenneth ryan\AppData\Local\Programs\Python\Python37

import kivy
kivy.require("1.9.0")

from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition
from kivy.properties import ObjectProperty, StringProperty
from kivy.core.window import Window
from kivy.uix.image import Image
from kivy.base import runTouchApp
from kivy.uix.scrollview import ScrollView
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout

class ScreenPop (Screen):
    def open_popup(self):
        the_popup = CustomPopup()
        the_popup.open()

class ScreenPop1 (Screen):
    def open_popup(self):
        the_popup1 = CustomPopup1()
        the_popup1.open()

class ScreenPop2 (Screen):
    def open_popup(self):
        the_popup2 = CustomPopup2()
        the_popup2.open()

class ScreenPop3 (Screen):
    def open_popup(self):
        the_popup3 = CustomPopup3()
        the_popup3.open()

class ScreenPop4 (Screen):
    def open_popup(self):
        the_popup4 = CustomPopup4()
        the_popup4.open()

class ScreenPop5 (Screen):
    def open_popup(self):
        the_popup5 = CustomPopup5()
        the_popup5.open()

class ScreenPop6 (Screen):
    def open_popup(self):
        the_popup6 = CustomPopup6()
        the_popup6.open()

class ScreenPop7 (Screen):
    def open_popup(self):
        the_popup7 = CustomPopup7()
        the_popup7.open()

class ScreenMain (Screen):
    pass

class ScreenChoices (Screen):
    def open_popup2(self):
        the_popup = CustomPopup2()
        the_popup.open()

class ScreenTwo (Screen):
    def open_popup(self):
        the_popup = CustomPopup()
        the_popup.open()

class ScreenThree (Screen):
    pass
    
class ScreenPrecalcov (Screen):
    def open_popup1(self):
        the_popup = CustomPopup1()
        the_popup.open()

class ScreenPre2 (Screen):
    pass

class ScreenPre3 (Screen):
    def open_popup3(self):
        the_popup = CustomPopup3()
        the_popup.open()

class ScreenPre4 (Screen):
    def open_popup5(self):
        the_popup = CustomPopup5()
        the_popup.open()

class ScreenPre5 (Screen):
    def open_popup7(self):
        the_popup = CustomPopup7()
        the_popup.open()

class ScreenPre6 (Screen):
    def open_popup4(self):
        the_popup = CustomPopup4()
        the_popup.open()

class ScreenPre7 (Screen):
    def open_popup6(self):
        the_popup = CustomPopup6()
        the_popup.open()

class Screen_Realnum (Screen):
    pass

class Screen_Realnum1 (Screen):
    pass

class Screen_Realnum2 (Screen):
    pass

class Screen_Realnum3 (Screen):
    pass

class Screen_Realnum4 (Screen):
    pass

class Screen_Intexp (Screen):
    pass

class Screen_Intexp1 (Screen):
    pass

class Screen_Intexp2 (Screen):
    pass

class Screen_Rad (Screen):
    pass

class Screen_Rad1 (Screen):
    pass

class ScreenRatio (Screen):
    pass

class ScreenRatio1 (Screen):
    pass

class ScreenRatio2 (Screen):
    pass

class ScreenRatio3 (Screen):
    pass

class ScreenRatio4 (Screen):
    pass

class ScreenRatio5 (Screen):
    pass

class ScreenRatio6 (Screen):
    pass

class ScreenRatio7 (Screen):
    pass

class ScreenAlg (Screen):
    pass

class ScreenAlg1 (Screen):
    pass

class ScreenAlg2 (Screen):
    pass

class ScreenAlg3 (Screen):
    pass

class ScreenAlg4 (Screen):
    pass

class ScreenAlg5 (Screen):
    pass

class ScreenAlg6 (Screen):
    pass

class ScreenAlg7 (Screen):
    pass

class ScreenEquate (Screen):
    pass

class ScreenEquate1 (Screen):
    pass

class ScreenEquate2 (Screen):
    pass

class ScreenEquate3 (Screen):
    pass

class ScreenEquate4 (Screen):
    pass

class ScreenEquate5 (Screen):
    pass

class ScreenEquate6 (Screen):
    pass

class ScreenFunction (Screen):
    pass

class ScreenFunction1 (Screen):
    pass

class ScreenFunction2 (Screen):
    pass

class ScreenFunction3 (Screen):
    pass

class ScreenFunction4 (Screen):
    pass

class ScreenFunction5 (Screen):
    pass

class ScreenFunction6 (Screen):
    pass

class ScreenPoly (Screen):
    pass

class ScreenPoly1 (Screen):
    pass

class ScreenPoly2 (Screen):
    pass

class ScreenPoly3 (Screen):
    pass

class ScreenPoly4 (Screen):
    pass

class ScreenPoly5 (Screen):
    pass

class ScreenPoly6 (Screen):
    pass

class ScreenPoly7 (Screen):
    pass

class ScreenPoly8 (Screen):
    pass

class ScreenPoly9 (Screen):
    pass

class ScreenExpo (Screen):
    pass

class ScreenExpo1 (Screen):
    pass

class ScreenExpo2 (Screen):
    pass

class ScreenExpo3 (Screen):
    pass

class ScreenExpo4 (Screen):
    pass

class ScreenExpo5 (Screen):
    pass

class ScreenAlgo (Screen):
    pass

class ScreenAlgo1 (Screen):
    pass

class ScreenAlgo2 (Screen):
    pass

class ScreenAlgo3 (Screen):
    pass

class ScreenAlgo4 (Screen):
    pass

class ScreenAlgo5 (Screen):
    pass

class ScreenAlgo6 (Screen):
    pass

class ScreenAlgo7 (Screen):
    pass

class ScreenUnit (Screen):
    pass

class ScreenUnit1 (Screen):
    pass

class ScreenUnit2 (Screen):
    pass

class ScreenUnit3 (Screen):
    pass

class ScreenUnit4 (Screen):
    pass

class ScreenUnit5 (Screen):
    pass

class ScreenGeo (Screen):
    pass

class ScreenGeo1 (Screen):
    pass

class ScreenGeo2 (Screen):
    pass

class ScreenGeo3 (Screen):
    pass

class ScreenGeo4 (Screen):
    pass

class ScreenGeo5 (Screen):
    pass

class ScreenConic (Screen):
    pass

class ScreenConic1 (Screen):
    pass

class ScreenConic2 (Screen):
    pass

class ScreenConic3 (Screen):
    pass

class ScreenConic4 (Screen):
    pass

class ScreenConic5 (Screen):
    pass

class ScreenConic6 (Screen):
    pass

class ScreenConic7 (Screen):
    pass

class ScreenConic8 (Screen):
    pass

class ScreenConic9 (Screen):
    pass

class ScreenConic10 (Screen):
    pass

class ScreenConic11 (Screen):
    pass

class ScreenConic12 (Screen):
    pass

class ScreenConic13 (Screen):
    pass

class ScreenConic14 (Screen):
    pass

class ScreenConic15 (Screen):
    pass

class ScreenConic16 (Screen):
    pass

class ScreenConic17 (Screen):
    pass

class ScreenConic18 (Screen):
    pass

class ScreenConic19 (Screen):
    pass

class ScreenConic20 (Screen):
    pass

class ScreenConic21 (Screen):
    pass

class ScreenConic22 (Screen):
    pass

class ScreenIntro (Screen):
    pass

class ScreenIntro1 (Screen):
    pass

class ScreenIntro2 (Screen):
    pass

class ScreenIntro3 (Screen):
    pass

class ScreenIntro4 (Screen):
    pass

class ScreenIntro5 (Screen):
    pass

class ScreenLimit (Screen):
    pass

class ScreenLimit1 (Screen):
    pass

class ScreenLimit2 (Screen):
    pass

class ScreenLimit3 (Screen):
    pass

class ScreenLimit4 (Screen):
    pass

class ScreenLimit5 (Screen):
    pass

class ScreenLimit6 (Screen):
    pass

class ScreenLimit7 (Screen):
    pass

class ScreenTwoLimit (Screen):
    pass

class ScreenTwoLimit1 (Screen):
    pass

class ScreenTwoLimit2 (Screen):
    pass

class ScreenTwoLimit3 (Screen):
    pass

class ScreenContinue (Screen):
    pass

class ScreenContinue1 (Screen):
    pass

class ScreenContinue2 (Screen):
    pass

class ScreenContinue3 (Screen):
    pass

class ScreenContinue4 (Screen):
    pass

class ScreenDerivatives (Screen):
    pass

class ScreenDerivatives1 (Screen):
    pass

class ScreenDerivatives2 (Screen):
    pass

class ScreenDerivatives3 (Screen):
    pass

class ScreenDerivatives4 (Screen):
    pass

class ScreenDiffrules (Screen):
    pass

class ScreenDiffrules1 (Screen):
    pass

class ScreenDiffrules2 (Screen):
    pass

class ScreenDiffrules3 (Screen):
    pass

class ScreenDiffrules4 (Screen):
    pass

class ScreenDiffrules5 (Screen):
    pass

class ScreenDiffrules6 (Screen):
    pass

class ScreenDiffrules7 (Screen):
    pass

class ScreenDiffrules8 (Screen):
    pass

class ScreenDiffrules9 (Screen):
    pass

class ScreenChainrule (Screen):
    pass

class ScreenChainrule1 (Screen):
    pass

class ScreenChainrule2 (Screen):
    pass

class ScreenChainrule3 (Screen):
    pass

class ScreenChainrule4 (Screen):
    pass

class ScreenChainrule5 (Screen):
    pass

class ScreenAngles (Screen):
    pass

class ScreenAngles1 (Screen):
    pass

class ScreenAngles2 (Screen):
    pass

class ScreenAngles3 (Screen):
    pass

class ScreenAngles4 (Screen):
    pass

class ScreenAngles5 (Screen):
    pass

class ScreenAngles6 (Screen):
    pass

class ScreenAngles7 (Screen):
    pass

class ScreenDifftrigo (Screen):
    pass

class ScreenDifftrigo1 (Screen):
    pass

class ScreenDifftrigo2 (Screen):
    pass

class ScreenGradient (Screen):
    pass

class ScreenGradient1 (Screen):
    pass

class ScreenGradient2 (Screen):
    pass

class ScreenCgradient (Screen):
    pass

class ScreenCgradient1 (Screen):
    pass

class ScreenCgradient2 (Screen):
    pass

class ScreenDefderivative (Screen):
    pass

class ScreenDefderivative1 (Screen):
    pass

class ScreenNotation (Screen):
    pass

class ScreenNotation1 (Screen):
    pass

class ScreenProperties (Screen):
    pass

class ScreenProperties1 (Screen):
    pass

class ScreenProperties2 (Screen):
    pass

class ScreenProperties3 (Screen):
    pass

class ScreenSummary (Screen):
    pass

class ScreenTangent (Screen):
    pass

class ScreenSecderivative (Screen):
    pass

class ScreenSecderivative1 (Screen):
    pass

class ScreenInverse (Screen):
    pass

class ScreenInverse1 (Screen):
    pass

class ScreenImplicit (Screen):
    pass

class ScreenImplicit1 (Screen):
    pass

class ScreenImplicit2 (Screen):
    pass

class ScreenProchain (Screen):
    pass

class ScreenProchain1 (Screen):
    pass

class ScreenProchain2 (Screen):
    pass

class ScreenProchain3 (Screen):
    pass

class ScreenProchain4 (Screen):
    pass

class ScreenProchain5 (Screen):
    pass

class ScreenProchain6 (Screen):
    pass

class ScreenProchain7 (Screen):
    pass

class ScreenAbout (Screen):
    pass

class ScreenFundaterms (Screen):
    pass

class ScreenFundaterms1 (Screen):
    pass

class ScreenSubstitution (Screen):
    pass

class ScreenSubstitution1 (Screen):
    pass

class ScreenIntegparts (Screen):
    pass

class ScreenIntegparts1 (Screen):
    pass

class ScreenIntegfrac (Screen):
    pass

class ScreenIntegfrac1 (Screen):
    pass

class ScreenElementary (Screen):
    pass

class ScreenElementary1 (Screen):
    pass

class ScreenHyperbolic (Screen):
    pass

class ScreenHyperbolic1 (Screen):
    pass

class ScreenPreexercise (Screen):
    pass

class ScreenPreexercise1 (Screen):
    pass

class ScreenPreexercise2 (Screen):
    pass

class ScreenPreexercise3 (Screen):
    pass

class ScreenBasicexercise (Screen):
    pass

class ScreenBasicexercise1 (Screen):
    pass

class ScreenBasicexercise2 (Screen):
    pass

class ScreenDiffexercise (Screen):
    pass

class ScreenDiffexercise1 (Screen):
    pass

class ScreenDiffexercise2 (Screen):
    pass

class ScreenIntegexercise (Screen):
    pass

class CustomPopup(Popup):
    pass

class CustomPopup1(Popup):
    pass

class CustomPopup2(Popup):
    pass

class CustomPopup3(Popup):
    pass

class CustomPopup4(Popup):
    pass

class CustomPopup5(Popup):
    pass

class CustomPopup6(Popup):
    pass

class CustomPopup7(Popup):
    pass

class Manager (ScreenManager):

    screen_main = ObjectProperty (None)
    screen_choices = ObjectProperty (None)
    screen_two = ObjectProperty (None)
    screen_three = ObjectProperty (None)
    screen_three = ObjectProperty (None)
    screen_precalcov = ObjectProperty (None)
    screen_pre2 = ObjectProperty (None)
    screen_pre3 = ObjectProperty (None)
    screen_pre4 = ObjectProperty (None)
    screen_pre5 = ObjectProperty (None)
    screen_pre6 = ObjectProperty (None)
    screen_pre7 = ObjectProperty (None)
    screen_realnum = ObjectProperty (None)
    screen_realnum1 = ObjectProperty (None)
    screen_realnum2 = ObjectProperty (None)
    screen_realnum3 = ObjectProperty (None)
    screen_realnum4 = ObjectProperty (None)
    screen_intexp = ObjectProperty (None)
    screen_intexp1 = ObjectProperty (None)
    screen_intexp2 = ObjectProperty (None)
    screen_rad = ObjectProperty (None)
    screen_rad1 = ObjectProperty (None)
    screen_ratio = ObjectProperty (None)
    screen_ratio1 = ObjectProperty (None)
    screen_ratio2 = ObjectProperty (None)
    screen_ratio3 = ObjectProperty (None)
    screen_ratio4 = ObjectProperty (None)
    screen_ratio5 = ObjectProperty (None)
    screen_ratio6 = ObjectProperty (None)
    screen_ratio7 = ObjectProperty (None)
    screen_alg = ObjectProperty (None)
    screen_alg1 = ObjectProperty (None)
    screen_alg2 = ObjectProperty (None)
    screen_alg3 = ObjectProperty (None)
    screen_alg4 = ObjectProperty (None)
    screen_alg5 = ObjectProperty (None)
    screen_alg6 = ObjectProperty (None)
    screen_alg7 = ObjectProperty (None)
    screen_equate = ObjectProperty (None)
    screen_equate1 = ObjectProperty (None)
    screen_equate2 = ObjectProperty (None)
    screen_equate3 = ObjectProperty (None)
    screen_equate4 = ObjectProperty (None)
    screen_equate5 = ObjectProperty (None)
    screen_equate6 = ObjectProperty (None)
    screen_function = ObjectProperty (None)
    screen_function1 = ObjectProperty (None)
    screen_function2 = ObjectProperty (None)
    screen_function3 = ObjectProperty (None)
    screen_function4 = ObjectProperty (None)
    screen_function5 = ObjectProperty (None)
    screen_function6 = ObjectProperty (None)
    screen_poly = ObjectProperty (None)
    screen_poly1 = ObjectProperty (None)
    screen_poly2 = ObjectProperty (None)
    screen_poly3 = ObjectProperty (None)
    screen_poly4 = ObjectProperty (None)
    screen_poly5 = ObjectProperty (None)
    screen_poly6 = ObjectProperty (None)
    screen_poly7 = ObjectProperty (None)
    screen_poly8 = ObjectProperty (None)
    screen_poly9 = ObjectProperty (None)
    screen_expo = ObjectProperty (None)
    screen_expo1 = ObjectProperty (None)
    screen_expo2 = ObjectProperty (None)
    screen_expo3 = ObjectProperty (None)
    screen_expo4 = ObjectProperty (None)
    screen_expo5 = ObjectProperty (None)
    screen_algo = ObjectProperty (None)
    screen_algo1 = ObjectProperty (None)
    screen_algo2 = ObjectProperty (None)
    screen_algo3 = ObjectProperty (None)
    screen_algo4 = ObjectProperty (None)
    screen_algo5 = ObjectProperty (None)
    screen_algo6 = ObjectProperty (None)
    screen_algo7 = ObjectProperty (None)
    screen_unit = ObjectProperty (None)
    screen_unit1 = ObjectProperty (None)
    screen_unit2 = ObjectProperty (None)
    screen_unit3 = ObjectProperty (None)
    screen_unit4 = ObjectProperty (None)
    screen_unit5 = ObjectProperty (None)
    screen_geo = ObjectProperty (None)
    screen_geo1 = ObjectProperty (None)
    screen_geo2 = ObjectProperty (None)
    screen_geo3 = ObjectProperty (None)
    screen_geo4 = ObjectProperty (None)
    screen_geo5 = ObjectProperty (None)
    screen_conic = ObjectProperty (None)
    screen_conic1 = ObjectProperty (None)
    screen_conic2 = ObjectProperty (None)
    screen_conic3 = ObjectProperty (None)
    screen_conic4 = ObjectProperty (None)
    screen_conic5 = ObjectProperty (None)
    screen_conic6 = ObjectProperty (None)
    screen_conic7 = ObjectProperty (None)
    screen_conic8 = ObjectProperty (None)
    screen_conic9 = ObjectProperty (None)
    screen_conic10 = ObjectProperty (None)
    screen_conic11 = ObjectProperty (None)
    screen_conic12 = ObjectProperty (None)
    screen_conic13 = ObjectProperty (None)
    screen_conic14 = ObjectProperty (None)
    screen_conic15 = ObjectProperty (None)
    screen_conic16 = ObjectProperty (None)
    screen_conic17 = ObjectProperty (None)
    screen_conic18 = ObjectProperty (None)
    screen_conic19 = ObjectProperty (None)
    screen_conic20 = ObjectProperty (None)
    screen_conic21 = ObjectProperty (None)
    screen_conic22 = ObjectProperty (None)
    screen_intro = ObjectProperty (None)
    screen_intro1 = ObjectProperty (None)
    screen_intro2 = ObjectProperty (None)
    screen_intro3 = ObjectProperty (None)
    screen_intro4 = ObjectProperty (None)
    screen_intro5 = ObjectProperty (None)
    screen_limit = ObjectProperty (None)
    screen_limit1 = ObjectProperty (None)
    screen_limit2 = ObjectProperty (None)
    screen_limit3 = ObjectProperty (None)
    screen_limit4 = ObjectProperty (None)
    screen_limit5 = ObjectProperty (None)
    screen_limit6 = ObjectProperty (None)
    screen_limit7 = ObjectProperty (None)
    screen_twolimit = ObjectProperty (None)
    screen_twolimit1 = ObjectProperty (None)
    screen_twolimit2 = ObjectProperty (None)
    screen_twolimit3 = ObjectProperty (None)
    screen_continue = ObjectProperty (None)
    screen_continue1 = ObjectProperty (None)
    screen_continue2 = ObjectProperty (None)
    screen_continue3 = ObjectProperty (None)
    screen_continue4 = ObjectProperty (None)
    screen_derivatives = ObjectProperty (None)
    screen_derivatives1 = ObjectProperty (None)
    screen_derivatives2 = ObjectProperty (None)
    screen_derivatives3 = ObjectProperty (None)
    screen_derivatives4 = ObjectProperty (None)
    screen_diffrules = ObjectProperty (None)
    screen_diffrules1 = ObjectProperty (None)
    screen_diffrules2 = ObjectProperty (None)
    screen_diffrules3 = ObjectProperty (None)
    screen_diffrules4 = ObjectProperty (None)
    screen_diffrules5 = ObjectProperty (None)
    screen_diffrules6 = ObjectProperty (None)
    screen_diffrules7 = ObjectProperty (None)
    screen_diffrules8 = ObjectProperty (None)
    screen_diffrules9 = ObjectProperty (None)
    screen_chainrule = ObjectProperty (None)
    screen_chainrule1 = ObjectProperty (None)
    screen_chainrule2 = ObjectProperty (None)
    screen_chainrule3 = ObjectProperty (None)
    screen_chainrule4 = ObjectProperty (None)
    screen_chainrule5 = ObjectProperty (None)
    screen_angles = ObjectProperty (None)
    screen_angles1 = ObjectProperty (None)
    screen_angles2 = ObjectProperty (None)
    screen_angles3 = ObjectProperty (None)
    screen_angles4 = ObjectProperty (None)
    screen_angles5 = ObjectProperty (None)
    screen_angles6 = ObjectProperty (None)
    screen_angles7 = ObjectProperty (None)
    screen_difftrigo = ObjectProperty (None)
    screen_difftrigo1 = ObjectProperty (None)
    screen_difftrigo2 = ObjectProperty (None)
    screen_gradient = ObjectProperty (None)
    screen_gradient1 = ObjectProperty (None)
    screen_gradient2 = ObjectProperty (None)
    screen_cgradient = ObjectProperty (None)
    screen_cgradient1 = ObjectProperty (None)
    screen_cgradient2 = ObjectProperty (None)
    screen_defderivative = ObjectProperty (None)
    screen_defderivative1 = ObjectProperty (None)
    screen_notation = ObjectProperty (None)
    screen_notation1 = ObjectProperty (None)
    screen_properties = ObjectProperty (None)
    screen_properties1 = ObjectProperty (None)
    screen_properties2 = ObjectProperty (None)
    screen_properties3 = ObjectProperty (None)
    screen_summary = ObjectProperty (None)
    screen_tangent = ObjectProperty (None)
    screen_secderivative = ObjectProperty (None)
    screen_secderivative1 = ObjectProperty (None)
    screen_inverse = ObjectProperty (None)
    screen_inverse1 = ObjectProperty (None)
    screen_implicit = ObjectProperty (None)
    screen_implicit1 = ObjectProperty (None)
    screen_implicit2 = ObjectProperty (None)
    screen_prochain = ObjectProperty (None)
    screen_prochain1 = ObjectProperty (None)
    screen_prochain2 = ObjectProperty (None)
    screen_prochain3 = ObjectProperty (None)
    screen_prochain4 = ObjectProperty (None)
    screen_prochain5 = ObjectProperty (None)
    screen_prochain6 = ObjectProperty (None)
    screen_prochain7 = ObjectProperty (None)
    screen_about = ObjectProperty (None)
    screen_fundaterms = ObjectProperty (None)
    screen_fundaterms1 = ObjectProperty (None)
    screen_substitution = ObjectProperty (None)
    screen_substitution1 = ObjectProperty (None)
    screen_integparts = ObjectProperty (None)
    screen_integparts1 = ObjectProperty (None)
    screen_integfrac = ObjectProperty (None)
    screen_integfrac1 = ObjectProperty (None)
    screen_elementary = ObjectProperty (None)
    screen_elementary1 = ObjectProperty (None)
    screen_hyperbolic = ObjectProperty (None)
    screen_hyperbolic1 = ObjectProperty (None)
    screen_preexercise = ObjectProperty (None)
    screen_preexercise1 = ObjectProperty (None)
    screen_preexercise2 = ObjectProperty (None)
    screen_preexercise3 = ObjectProperty (None)
    screen_basicexercise = ObjectProperty (None)
    screen_basicexercise1 = ObjectProperty (None)
    screen_basicexercise2 = ObjectProperty (None)
    screen_diffexercise = ObjectProperty (None)
    screen_diffexercise1 = ObjectProperty (None)
    screen_diffexercise2 = ObjectProperty (None)
    screen_integexercise = ObjectProperty (None)
    screen_pop = ObjectProperty (None)
    screen_pop1 = ObjectProperty (None)
    screen_pop2 = ObjectProperty (None)
    screen_pop3 = ObjectProperty (None)
    screen_pop4 = ObjectProperty (None)
    screen_pop5 = ObjectProperty (None)
    screen_pop6 = ObjectProperty (None)
    screen_pop7 = ObjectProperty (None)

class ScreenApp (App):    

    def build (self):
        m = Manager (transition = SlideTransition ())
        Window.clearcolor = (.139, .0, .0, 1)
        return m

if __name__ == '__main__':
    Mymine = ScreenApp ()
    Mymine.run ()
