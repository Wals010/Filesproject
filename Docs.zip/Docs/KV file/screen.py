#:kivy 1.9.0

<CustomPopup>:
    size_hint: 0.8, 0.5
    auto_dismiss: False
    title: "THE QUOTE"
    Button:
        text: "[b]\'\'Mathematics is not only for solving\nnumbers. It\'s also for dividing\nsorrow, subtracting sadness,\nadding happiness and\nmultiplying love and forgiveness[b]\'\'"
        halign: 'center'
        font_size: 16
        markup: True
        on_press: root.dismiss ()

<CustomPopup1>:
    size_hint: 0.8, 0.5
    auto_dismiss: False
    title: "THE QUOTE"
    Button:
        text: "[b]\'\'Life is like calculus.\nYou just need to limit\nyour spirits to infinity.\'\'\n\n- Manjita Sinha -[b]"
        halign: 'center'
        font_size: 16
        markup: True
        on_press: root.dismiss ()

<CustomPopup2>:
    size_hint: 0.8, 0.5
    auto_dismiss: False
    title: "THE QUOTE"
    Button:
        text: "[b]\'\'Your limits are somewhere up there,\nwaiting for you\nto reach beyond infinity.\'\'\n\n- Henry H. Arnold -[b]"
        halign: 'center'
        font_size: 16
        markup: True
        on_press: root.dismiss ()

<CustomPopup3>:
    size_hint: 0.8, 0.5
    auto_dismiss: False
    title: "THE QUOTE"
    Button:
        text: "[b]\'\'Science is the Differential Calculus\nof the mind. Art the\nIntegral Calculus; they may\nbe beautiful when apart, but are\ngreatest only when combined.\'\'\n\n- Ronald Ross -[b]"
        halign: 'center'
        font_size: 16
        markup: True
        on_press: root.dismiss ()

<CustomPopup4>:
    size_hint: 0.8, 0.5
    auto_dismiss: False
    title: "THE QUOTE"
    Button:
        text: "[b]\'\'The calculus is the greatest aid\nwe have to the application\nof physical truth in\nthe broadcast sense of the world.\'\'\n\n- William Fogg Osgood -[b]"
        halign: 'center'
        font_size: 16
        markup: True
        on_press: root.dismiss ()

<CustomPopup5>:
    size_hint: 0.8, 0.5
    auto_dismiss: False
    title: "THE QUOTE"
    Button:
        text: "[b]\'\'Calculus required continuity,\nand continuity was supposed\nto require the infinitely little;\nbut nobody could discover\nwhat the infinitely little might be.\'\'\n\n- Bertrand Russell -[b]"
        halign: 'center'
        font_size: 16
        markup: True
        on_press: root.dismiss ()

<CustomPopup6>:
    size_hint: 0.8, 0.5
    auto_dismiss: False
    title: "THE QUOTE"
    Button:
        text: "[b]\'\'Mathematics as an expression of the\nhuman mind reflects the\nactive will, the contemplative reason,\nand the desire for aesthetic perfection.\'\'\n\n- Richard Courant -[b]"
        halign: 'center'
        font_size: 16
        markup: True
        on_press: root.dismiss ()

<CustomPopup7>:
    size_hint: 0.8, 0.5
    auto_dismiss: False
    title: "THE QUOTE"
    Button:
        text: "[b]\'\'There is geometry in\nthe humming of the strings,\nthere is music in the\nspacing of the spheres.\'\'\n\n- Pythagoras -[b]"
        halign: 'center'
        font_size: 16
        markup: True
        on_press: root.dismiss ()

<ScreenMain>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Image:
            source: "Doc/cover.png"
            image_size: 20
            pos_hint: {'x': 0, 'y': 0.20}
            image_size: self.width, self.texture.height
            keep_ratio: False
            allow_stretch: False
            keep_data: True

        Image:
            source: "Doc/unnamed2.png"
            image_size: 5
            pos_hint: {'x': 0, 'y': -0.38}
            keep_ratio: False
            allow_stretch: False
            keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Label:
            text: "[b]\n\n\n\n\n\nLEARN CALCULUS APPLICATION[b]"
            font_size: 20
            halign: 'center'
            markup: True
            background_color: (0.404, 0.227, 0.718, 1)
            font_color: (0.404, 0.227, 0.718, 1)
            
        Button:
            size_hint: 0.20, 0.05
            pos_hint: {'x': 0.40, 'y': 0.15}
            text: "[b]START[b]"
            font_size: 20
            markup: True
            background_color: (0.255, 0.218, 0.185, 0)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen1'

        Button:
            size_hint: 0.20, 0.05
            pos_hint: {'x': 0.40, 'y': 0.05}
            text: "[b]ABOUT[b]"
            font_size: 20
            markup: True
            background_color: (0.255, 0.218, 0.185, 0)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenabout'


<ScreenChoices>: #PRE CAL, BASIC CAL, DIF CAL, INTEG CAL
    BoxLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Image:
            source: "Doc/giphy.gif"
            image_size: 100
            pos_hint: {'x': 0, 'y': 0.20}
            image_size: self.width, self.texture.height
            keep_ratio: False
            allow_stretch: True
            keep_data: True
            anim_delay: 0.25
            anim_loop: 0
            nocache: True

        Button:
            size_hint: 0.45, 0.15
            pos_hint: {'x': 0.28, 'y': 0.05}
            text: "[b]Fundamentals[b]"
            halign: 'center'
            font_size: 20
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen2'
                
        Button:
            size_hint: 0.45, 0.15
            pos_hint: {'x': 0.28, 'y': 0.05}
            text: "[b]Pre-Calculus[b]"
            halign: 'center'
            font_size: 20
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp1'
                
        Button:
            size_hint: 0.45, 0.15
            pos_hint: {'x': 0.28, 'y': 0.05}
            text: "[b]Basic Calculus[b]"
            halign: 'center'
            font_size: 20
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp3'
                
        Button:
            size_hint: 0.45, 0.15
            pos_hint: {'x': 0.28, 'y': 0.05}
            text: "[b]Differential Calculus[b]"
            halign: 'center'
            font_size: 20
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp4'
                
        Button:
            size_hint: 0.45, 0.15
            pos_hint: {'x': 0.28, 'y': 0.05}
            text: "[b]Integral Calculus[b]"
            halign: 'center'
            font_size: 20
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp5'

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.05}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenmain'

        Button:
            pos_hint: {'x': 0.82, 'y': 0.05}
            size_hint: 0.15, 0.05
            text: "Quote"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press: root.open_popup2()
                
<ScreenPrecalcov>: #FOR PRECALCULUS PART
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.40, 0.05
            pos_hint: {'x': 0.29, 'y': 0.85}
            text: "[b]FUNCTIONS[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenfunction'

        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.75}
            text: "[b]POLYNOMIAL AND\nRATIONAL FUNCTIONS[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly'

        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.65}
            text: "[b]EXPONENTIAL AND\nLOGARITHMIC FUNCTIONS[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenexpo'

        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.55}
            text: "[b]TRIGO FUNCTIONS:\nUNIT CIRCLE APPROACH[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenunit'

        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.45}
            text: "[b]ANALYTIC\nGEOMETRY[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screengeo'

        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.35}
            text: "[b]CONIC\nSECTIONS[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic'

        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.25}
            text: "[b]EXERCISES[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpreexercise'

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            pos_hint: {'x': 0.82, 'y': 0.05}
            size_hint: 0.15, 0.05
            text: "Quote"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press: root.open_popup1()

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.05}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen1'

<ScreenPre3>:   #BASIC CALCULUS PARTS/COVER AREA
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.05}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen1'

        Button:
            pos_hint: {'x': 0.82, 'y': 0.1}
            size_hint: 0.15, 0.05
            text: "Quote"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press: root.open_popup3()

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.05}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp6'

        Button:
            size_hint: 0.40, 0.05
            pos_hint: {'x': 0.29, 'y': 0.80}
            text: "[b]INTRODUCTION[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenintro'


        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.70}
            text: "[b]EXPONENTS: BASICS\n AND PROPERTIES[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp2'

        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.60}
            text: "[b]LIMITS OF\nSEQUENCES[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenlimit'

        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.50}
            text: "[b]ONE-SIDED\nLIMITS[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenlimit3'

        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.40}
            text: "[b]TWO-SIDED\nLIMITS[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screentwolimit'

        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.30}
            text: "[b]CONTINUOUS\nFUNCTIONS[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screencontinue'

        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.20}
            text: "[b]DERIVATIVES[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenderivatives'

<ScreenPre2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        ScrollView:
            Label:
                text: str ('[b]Basic Definition and Properties[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True
                
    GridLayout:
        rows: 4
        col: 1
        pos_hint: {'top': 1.1, 'left': 1.1}
        Image:
            source: "Doc/ex2.png"
            image_size: self.width, self.texture.height
            
            keep_data: True

    GridLayout:
        rows: 4
        col: 1
        pos_hint: {'top': 1.05, 'left': 1.05}
        Image:
            source: "Doc/ex3.png"
            image_size: self.width, self.texture.height
            pos_hint: {'x': 0, 'y': 0}
            keep_data: True
    
    GridLayout:
        rows: 4
        col: 1
        pos_hint: {'top': 0.94, 'left': 0.94}
        Image:
            source: "Doc/format.png"
            image_size: self.width, self.texture.height
            pos_hint: {'x': 0, 'y': -0.2}
            keep_data: True

    GridLayout:
        rows: 4
        col: 1
        pos_hint: {'top': 0.82, 'left': 0.82}
        Image:
            source: "Doc/exp1.png"
            image_size: self.width, self.texture.height
            pos_hint: {'x': 0, 'y': -0.}
            keep_ratio: True
            allo_stretch: False
            keep_data: True

    GridLayout:
        rows: 4
        col: 1
        pos_hint: {'top': 0.77, 'left': 0.77}
        Image:
            source: "Doc/ex4.png"
            image_size: self.width, self.texture.height
            pos_hint: {'x': 0, 'y': -0.1}
            keep_data: True

    GridLayout:
        rows: 4
        col: 1
        pos_hint: {'top': 0.66, 'left': 0.66}
        Image:
            source: "Doc/format2.png"
            image_size: self.width, self.texture.height
            pos_hint: {'x': 0, 'y': -0.1}
            keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('\n\n  For any real number base x, we define the power of x: x^0 = 1, x^1 = x, x^2 = x * x, x^3 = x * x * x, etc. The exception is 0^0 because it is called as indeterminate. Powers are also called exponents.\n\nExample:\n5^0 = 1\n11.2^1 = 11.2\n3^3 = 3 x 3 x 3 = 27\n\n  Also, we can define fractional exponents in terms of roots such as:\n\n\n\n\n  In general, we have\n\n\n\n\n  it is the n^th root of x, raised to the m^th power. Example:\n\n\n\n\n Finally, we can define negative exponents:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.027}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.027}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen3'

<ScreenPre4>:   # FOR DIFFERENTIAL CALCULUS
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.05}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.05}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp7'

        Button:
            pos_hint: {'x': 0.82, 'y': 0.1}
            size_hint: 0.15, 0.05
            text: "Quote"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press: root.open_popup5()

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.80}
            text: "[b]THE GRADIENT OF SECANTS\nAND TANGENTS TO A GRAPH[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screengradient'

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.70}
            text: "[b]CALCULATING THE\nGRADIENT OF Y = X^2[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screencgradient'

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.60}
            text: "[b]DEFINITON OF\nTHE DERIVATIVE[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screendefderivative'

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.50}
            text: "[b]NOTATION FOR\nTHE DERIVATIVE[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screennotation'

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.40}
            text: "[b]PROPERTIES OF\nTHE DERIVATIVE[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenproperties'

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.30}
            text: "[b]THE PRODUCT, QUOTIENT\nAND CHAIN RULES[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenprochain'

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.20}
            text: "[b]SUMMARY OF\nDIFFERENTIATION RULES[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screensummary'

<ScreenPre7>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.05}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.05}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen1'

        Button:
            pos_hint: {'x': 0.82, 'y': 0.1}
            size_hint: 0.15, 0.05
            text: "Quote"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press: root.open_popup6()

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.80}
            text: "[b]THE TANGENT LINE\nTO A GRAPH[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screentangent'

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.70}
            text: "[b]THE SECOND\nDERIVATIVE[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screensecderivative'

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.60}
            text: "[b]DIFFERENTIATION\nOF INVERSES[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screeninverse'

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.50}
            text: "[b]IMPLICIT\nDIFFERENTIATION[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenimplicit'

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.40}
            text: "[b]EXERCISES[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffexercise'

<ScreenPre5>:   # FOR INTEGRAL CALCULUS
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.05}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen1'

        Button:
            pos_hint: {'x': 0.82, 'y': 0.05}
            size_hint: 0.15, 0.05
            text: "Quote"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press: root.open_popup7()

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.80}
            text: "[b]FUNDAMENTAL THEOREM IN\nTERMS OF DIFFERENTIAL[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenfundaterms'

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.70}
            text: "[b]INTEGRATION BY\nSUBSTITUTION[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screensubstitution'

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.60}
            text: "[b]INTEGRATION BY\nPARTS[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenintegparts'

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.50}
            text: "[b]INTEGRATION BY\nPARTIAL FRACTIONS[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenintegfrac'

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.40}
            text: "[b]ELEMENTARY INTEGRALS[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenelementary'

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.30}
            text: "[b]HYPERBOLIC FUNCTIONS[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenhyperbolic'

        Button:
            size_hint: 0.60, 0.07
            pos_hint: {'x': 0.20, 'y': 0.20}
            text: "[b]EXERCISES[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenintegexercise'

<ScreenPre6>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.05}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp3'

        Button:
            pos_hint: {'x': 0.82, 'y': 0.1}
            size_hint: 0.15, 0.05
            text: "Quote"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press: root.open_popup4()

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.05}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen1'

        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.75}
            text: "[b]RULES FOR\nDIFFERENTIATION[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules'

        Button:
            size_hint: 0.40, 0.05
            pos_hint: {'x': 0.29, 'y': 0.65}
            text: "[b]CHAIN RULE[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenchainrule'

        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.55}
            text: "[b]ANGLES AND\nTRIGONO FUNCTIONS[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenangles'

        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.45}
            text: "[b]DIFFERENTIATION OF\nTRIGO FUNCTIONS[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screendifftrigo'

        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.35}
            text: "[b]EXERCISES[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenbasicexercise'

<ScreenTwo>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.40, 0.05
            pos_hint: {'x': 0.29, 'y': 0.80}
            text: "[b]REAL NUMBERS[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_realnum'


        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.70}
            text: "[b]EXPONENTS AND\nRADICALS[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_intexp'

        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.60}
            text: "[b]ALGEBRAIC\nEXPRESSIONS[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenratio'

        Button:
            size_hint: 0.40, 0.07
            pos_hint: {'x': 0.29, 'y': 0.50}
            text: "[b]RATIONAL\nEXPRESSIONS[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalg'

        Button:
            size_hint: 0.40, 0.05
            pos_hint: {'x': 0.29, 'y': 0.42}
            text: "[b]EQUATIONS[b]"
            font_size: 14
            halign: 'center'
            markup: True
            background_color: (0.3, 0.4, 0.5, 1)
            on_release:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenequate'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen1'

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            pos_hint: {'x': 0.82, 'y': 0.03}
            size_hint: 0.15, 0.05
            text: "Quote"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press: root.open_popup()

<ScreenThree>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.43, 'left': 1.43}
            Image:
                source: "Doc/format3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.}
                keep_ratio: True
                allo_stretch: False
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.35, 'left': 1.35}
            Image:
                source: "Doc/format4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.20, 'left': 1.20}
            Image:
                source: "Doc/exp2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.12, 'left': 1.12}
            Image:
                source: "Doc/exp3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.97, 'left': 0.97}
            Image:
                source: "Doc/edit1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.85, 'left': 0.85}
            Image:
                source: "Doc/edit2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.73, 'left': 0.73}
            Image:
                source: "Doc/edit3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True
        
        ScrollView:
            Label:
                text: str ('  Thus,\n\n\n\n\n\n\n\n  Examples:\n\n\n\n\n\n\n\n  The properties of derivatives are the following:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True
                
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.05}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.05}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp3'

<Screen_Realnum>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        ScrollView:
            Label:
                text: str ('[b]Introductory to Real Numbers[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True
                
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: (str ("\n\nThe different types of real numbers were invented to meet specific needs. For example, natural numbers are needed for counting, negative numbers for describing debt or below-zero temperatures, rational numbers for concepts like half a gallon of milk, and irrational numbers for measuring cetain distances, like the diagonal of a square."))
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\nThere are different types of real numbers:\nRational numbers - those numbers taking two ratios of integers.\nExamples: 2/3, 5/6, 3/2\n\nIrrational numbers - are numbers that cannot be expressed in ratio of integers. Thus, it uses radicals.\nExamples: pi, pi/2, square root of 12\n\nNatural numbers - are numbers consist of only positive real numbers.\nExamples: 1, 2, 3, 4, 5\n\nIntegers - are numbers consist of natural numbers, negatives and 0.\nExamples: -2, -1, 0, 1, 2')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nProperties of Real Numbers\nCommutative Properties:\nWhen we add two numbers, order doesn\'t matter.\nWhen we multiply two numbers, order doesn\'t matter.\n\nStructure:\na + b = b + a\na * b = b * a')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_realnum1'

<Screen_Realnum1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        ScrollView:
            Label:
                text: str ('Example:\n7 + 3 = 3 + 7\n5 * 3 = 3 * 5\n\nAssociative Properties:\nWhen we add three numbers, it doesn\'t matter which two we add first.\nWhen we multiply three numbers, it doesn\'t matter which two we multiply first.\n\nStructure:\n(a + b) + c = a + (b + c)\n(a * b) * c = a * (b * c)')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample:\n(2 + 4) + 7= 2 + (4 + 7)\n(3 * 7) * 5 = 3 * (7 * 5)')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nDistributive Property:\nWhen we multiply a number by a sum of two numbers, we get the same result as we would get if we multiply the number by each of the terms and then add the results.\n\nStructure:\na * (b + c) = a * b + a * c\n(b + c) * a = a * b + a * c')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample:\n2 * (3 + 5) = 2 * 3 + 2 * 5\n(3 + 5) * 2 = 2 * 3 + 2 * 5')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True
                
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_realnum'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_realnum2'

<Screen_Realnum2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        ScrollView:
            Label:
                text: str ('[b]Properties of Negatives[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        ScrollView:
            Label:
                text: str ('\n\n1. (-1) * a = -a')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n[b]Example:[b]\n(-1) * 5 = -5')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n2. - (-a) = a')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n[b]Example:[b]\n -(-5) = 5')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n3. (-a)b = a(-b) = - (ab)')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Example:[b]\n (-5) 7 = 5 (-7) = - (5 * 7)')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n4. (-a) *(-b) = ab')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Example:[b]\n (-5) * (-4) = 5 * 4')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5. - (a + b) = - a - b')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Example:[b]\n - ( 3 + 5) = -3 - 5')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n6. - (a - b) = b - a')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Example:[b]\n - (5 - 8) = 8 - 5')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True


    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_realnum1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_realnum3'

<Screen_Realnum3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        ScrollView:
            Label:
                text: str ('[b]Properties of Fractions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        ScrollView:
            Label:
                text: str ('\n\n1. a/b * c/d = ac/bd\nWhen multiplying fractions, multiply numerators and denominators.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n[b]Example:[b]\n2/3 * 5/7 = 2*5/3*7 = 10/21')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n2. a/b % c/d = a/b * d/c\nWhen dividing fractions, invert the divisor and multiply.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n[b]Example:[b]\n2/3 % 5/7 = 2/3 * 7/5 = 14/15')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n3. a/c + b/c = a + b/c\nWhen adding fractions with the same denominator, add the numerators.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Example:[b]\n2/5 + 7/5 = 2 + 7/5 = 9/5')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n4. a/b + c/d = ad + bc/bd\nWhen adding fractions with different denominators, find a common denominator. Then add the numerators.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Example:[b]\n2/5 + 3/7 = 2 * 7 + 3 * 5/35 = 29/35')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5. ac/bc = a/b\nCancel numbers that are common factors in numerator and denominator.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True   
                
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_realnum2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_realnum4'

<Screen_Realnum4>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Example:[b]\n2*5/3*5 = 2/3')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n6. If a/b = c/d, then ad = bc\n Cross-multiply.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n[b]Example:[b]\n2/3 = 6/9, so 2 * 9 = 3 * 6')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_realnum3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen2'

<Screen_Intexp>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        ScrollView:
            Label:
                text: str ('[b]Integer Exponents[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nA product of identical numbers is usually written in exponential notation. For example, 5 * 5 * 5 is written as 5^3. In general, we have the following definition.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.28, 'left': 1.28}
            Image:
                source: "Doc/intexp.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\nExample:\na. (1/2)^5 = (1/2)(1/2)(1/2)(1/2)(1/2) = 1/32\nb. (-3)^4 = (-3) * (-3) * (-3) * (-3) = 81\nc. -3^4 = -(3*3*3*3) = -81')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True
                
        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n There is also a case that the exponents is zero and negative in manner. Here comes the definition of it.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.88, 'left': 0.88}
            Image:
                source: "Doc/intexp.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExamples:\na. (4/7)^0 = 1\nb. x^-1 = 1/x^ 1 or 1/x\nc. (-2)^-3 = 1/(-2)^3 = 1/-8 = -1/8\n\nFamiliarity with the following rules is essential for our work with exponents and bases.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True
                
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_intexp1'

<Screen_Intexp1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        ScrollView:
            Label:
                text: str ('[b]Law of Exponents[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n1. a^ma^n = a^m+n\nTo multiply two powers of the same number, add the exponents.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n[b]Example:\n 3^2 * 3^5 = 3^2+5 = 3^7[b]')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n2. a^m/a^n = a^m-n\nTo divide two powers of the same number, subtract the exponents.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n[b]Example:\n 3^5/3^2 = 3^5-2 = 3^3[b]')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n3. (a^m)^n = a^mn\nTo raise a power to a new power, multiply the exponents.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Example:\n (3^2)^5 = 3^2*5 = 3^10[b]')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n4. (ab)^n = a^n * b^n\nTo raise a product to a power, raise each factor to the power.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Example:\n (3*4)^2 = 3^2*4^2[b]')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5. (a/b)^n = a^n/b^n\nTo raise a quotient to a power, raise the both numerator and denominator to the power.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True
                
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_intexp'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_intexp2'

<Screen_Intexp2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Example:\n (3/4)^2 = 3^2/4^2[b]')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n6. (a/b)^-n = (b/a)^n\nTo raise a function to a negative power, invert the fraction and change the sign of the exponent.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n[b]Example:\n (3/4)^-2 = (4/3)^2[b]')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n7. (a^-n/b^-m = b^m/a^n\nTo move a number raised to a power from numerator to denominator or from a denominator to numerator, change the sign of the exponent.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Example:\n 3^-2/4^-5 = 4^5/3^2[b]')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_intexp1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_rad'

<Screen_Rad>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        ScrollView:
            Label:
                text: str ('[b]Radicals[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nWe know what 2^n means whenever n is an integer. To give meaning to a power, such as 2^4/5, whose exponent is a rational number, we need to discuss radicals. The check-like symbol means \"the positive square root of\". Thus')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\nSince a = b^2 is greater than or equal to 0, the symbol square root of a makes sense only when a is greater than or equal to zero. For instance, ')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\nSquare roots are special cases of nth roots. The nth root of x is the number that, when raised to the nth power, gives x.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.14, 'left': 1.14}
            Image:
                source: "Doc/rad1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.3, 'left': 1.3}
            Image:
                source: "Doc/rad.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.99, 'left': 0.99}
            Image:
                source: "Doc/rad2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.73, 'left': 0.73}
            Image:
                source: "Doc/rad4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.87, 'left': 0.87}
            Image:
                source: "Doc/rad3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True
                
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_intexp2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_rad1'

<Screen_Rad1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        ScrollView:
            Label:
                text: str ('[b]Properties of Radicals[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.3, 'left': 1.3}
            Image:
                source: "Doc/rad5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n[b]Rational Exponents[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nTo define what is meant by a rational exponent or equivalently, a fractional exponent such as a^1/3, we need to use radicals. To give meaning to the symbol a^1/n in a way that is consistent with the Laws of exponents, we would have to have')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n(a^1/n)^n = a^(1/n)^n = a^1 = a')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nSo by definition of the nth root,\n\n\nIn general, we define rational exponents as follows.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.82, 'left': 0.82}
            Image:
                source: "Doc/rad6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.68, 'left': 0.68}
            Image:
                source: "Doc/rad7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True
                
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen_rad'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen2'
                
<ScreenRatio>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Introduction to Algebraic Expressions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nA variable is a letter than can represent any number from a given set of numbers. If we start with variables such x, y, and z and some real numbers, and combine them using addition, subtraction, multiplication, division, powers and roots, we obtain an algebraic expression. Here are some examples: ')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.27, 'left': 1.27}
            Image:
                source: "Doc/ratio.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\nA monomial is an expression of the form ax^k, where a is a real number and k is a non-negative integer. A binomial is a sum of two monomials and a trinomial is a sum of three monomials. In general, a sum of monomials is called a polynomial. For example, the first expression listed above is a polynomial, but the other two are not.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.955, 'left': 0.955}
            Image:
                source: "Doc/ratio1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nNote that the degree of polynomial is the highest power of the variable that appears in the polynomial.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe next table shows different polynomials, the type of it, the different terms the polynomial has and the degree it possess.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
    
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenratio1'

<ScreenRatio1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]\n\n\n\n\n\n\n\nAdding and Subtracting Polynomials[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\nWe add and subtract polynomials using the properties of real numbers. The idea is to combine like terms (that is, terms with the same variables raised to the same powers) using theDistributive Property. For instance,')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5x^7 + 3x^7 = (5 + 3)x^7 = 8x^7')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nIn subracting polynomials, we have to remember that is a minus sign precedes an expression in parentheses, then the sign of every term within the parentheses is changed when we remove the parentheses:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n- (b + c) = -b - c')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[This is simply a case of the Distributive Property, a(b + c) = ab + ac, with a = -1.]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.355, 'left': 1.355}
            Image:
                source: "Doc/ratio2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenratio'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenratio2'

<ScreenRatio2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]\n\n\n\n\n\n\n\n\nMultiplying Algebraic Expressions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nTo find the product of polynomials or other algebraic expressions, we need to use the Distributive Property repeatedly. In particular, using it, three times on the product of two binomials, we get')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThis says that we multiply the two factors by multiplying each term in one factor by each term in the other factor and adding these products. Schematically, we have')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.94, 'left': 0.94}
            Image:
                source: "Doc/ratio4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.31, 'left': 1.31}
            Image:
                source: "Doc/ratio3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.75, 'left': 0.75}
            Image:
                source: "Doc/ratio5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenratio1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenratio3'

<ScreenRatio3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('In general, we can multiply two algebraic expressions by using the Distributive Property and the Laws of Exponents')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.375, 'left': 1.375}
            Image:
                source: "Doc/ratio6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.025, 'left': 1.025}
            Image:
                source: "Doc/ratio7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\nWhen we multiply trinomials or other polynomials with more terms, we use the Distributive Property. It is also helpful to arrange our work in table form. The next example illustrates both methods.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('[b]\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nSpecial Product Formulas[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nCertain types of products occur so frequently that you should memorize them. You can verify the following formulas by performing the multiplication.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenratio2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenratio4'

<ScreenRatio4>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.37, 'left': 1.37}
            Image:
                source: "Doc/ratio8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.02, 'left': 1.02}
            Image:
                source: "Doc/ratio9.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.76, 'left': 0.76}
            Image:
                source: "Doc/ratio10.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\nThe key idea in using these formulas (or any other formula in algebra) is the Principle of Substitution: We may substitute any algebraic expression for any letter in a formula. For example, to find (x^2 + y^3)^2 we use Product formula 2, substituting x^2 for A and y^3 for B, to get')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenratio3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenratio5'

<ScreenRatio5>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Factoring Common Factors[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nWe use the Distributive Property to expand algebraic expressions. We sometimes need to reverse this process (again using the Distributive Property) by factoring an expression as a product of simpler ones. For example, we can write')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.23, 'left': 1.23}
            Image:
                source: "Doc/ratio11.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\nWe say that x - 2 and x + 2 are factors of x^2 - 4. The easiest type of factoring occurs when the terms have a common factor.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.82, 'left': 0.82}
            Image:
                source: "Doc/ratio12.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenratio4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenratio6'

<ScreenRatio6>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Factoring Trinomials[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nTo factor a trinomial of the form x^2 + bx + c, we note that')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n(x + r)(x + s) = x^2 + (r + s)x + rs')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\nso we need to choose numbers r and s so that r + s = b and rs = c.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nTo factor a trinomial of the form ax^2 + bx + c with a is not equal to 1, we look  for factors of the form px + r and qx + s:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nax^2 + bx + c = (px + r)(qx + s) = pqx^2 + (ps + qr)x + rs')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nTherefore, we try to find numbers p, q, r, and s such that pq = a, rs = c, ps + qr = b. If these numbers are all integers, then we will have a limited number of possibilities to try for p, q, r, and s.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.2, 'left': 1.2}
            Image:
                source: "Doc/ratio13.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.75, 'left': 0.75}
            Image:
                source: "Doc/ratio14.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenratio5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenratio7'

<ScreenRatio7>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Special Factoring Formulas[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nSome special algebraic expressions can be factored using the following formulas. The first three are simply Special Product Formulas written backward.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\nDifference of squares')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\nA^2 - B^2 = (A - B)(A + B)')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\nPerfect square')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\nA^2 + 2AB + B^2 = (A + B)^2\nA^2 - 2AB + B^2 = (A - B)^2')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nDifference of cubes')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nA^3 - B^3 = (A - B)(A^2 + AB + B^2)')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nSum of cubes')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nA^3 + B^3 = (A + B)(A^2 - AB + B^2)')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenratio6'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen2'

<ScreenAlg>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('A quotient of two algebraic expressions is called a fractional expression. Here are some examples:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.39, 'left': 1.39}
            Image:
                source: "Doc/alg.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\nA rational expression is a fractional expression where both the numerator and denominator are polynomials. For exmple, the following are rational expressions:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.20, 'left': 1.20}
            Image:
                source: "Doc/alg1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\nIn this section we will learn how to perform algebraic operations on rational expressions.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n[b]The Domain of an Algebraic Expression[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nIn general, an algebraic expression may not defined for all values of the variable. The domain of an algebraic expression is the set of real numbers that the variable is permitted to have. The table in the margin gives some basic expressions and their domains.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': .73, 'left': .73}
            Image:
                source: "Doc/alg2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalg1'

<ScreenAlg1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.25, 'left': 1.25}
            Image:
                source: "Doc/alg3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.765, 'left': 0.765}
            Image:
                source: "Doc/alg4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Simplifying Rational Expressions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nTo simplify rational expressions, we factor both numerator and denominator and use the following property of fractions:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThis allow us to cancel common factors from the numerator and denominator.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalg'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalg2'

<ScreenAlg2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.39, 'left': 1.39}
            Image:
                source: "Doc/alg5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n[b]Multiplying and Dividing Rational Expressions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\nTo multiply rational expressions, we use the following property of fractions.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.02, 'left': 1.02}
            Image:
                source: "Doc/alg6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThis says that to multiply two fractions we multiply their numerators and multiply their denominators.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.74, 'left': 0.74}
            Image:
                source: "Doc/alg7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalg1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalg3'

<ScreenAlg3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('This says to divide a fraction by another fraction, we invert the divisor and multiply.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.285, 'left': 1.285}
            Image:
                source: "Doc/alg8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n[b]Adding and Subtracting Rational Expressions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nTo add or subtract rational expressions, we first find a common denominator and then use the following property of fractions:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.845, 'left': 0.845}
            Image:
                source: "Doc/alg9.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nAlthough any common denominator will work, it is best to use the least common denominator (LCD). The LCD is found by factoring each denominator and taking the product of the distinct factors, using the highest power that appears in any of the factors.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalg2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalg4'

<ScreenAlg4>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.33, 'left': 1.33}
            Image:
                source: "Doc/alg10.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.03, 'left': 1.03}
            Image:
                source: "Doc/alg11.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.68, 'left': 0.68}
            Image:
                source: "Doc/alg13.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Compound Fractions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nA compound fraction is a fraction in which the numerator, the denominator, or both are themselves fractional expressions.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalg3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalg5'

<ScreenAlg5>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.4, 'left': 1.4}
            Image:
                source: "Doc/alg12.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.17, 'left': 1.17}
            Image:
                source: "Doc/alg14.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe next two examples shows situations in calculus that require the ability to work with fractional expressions.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.78, 'left': 0.78}
            Image:
                source: "Doc/alg15.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalg4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalg6'

<ScreenAlg6>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.37, 'left': 1.37}
            Image:
                source: "Doc/alg16.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.14, 'left': 1.14}
            Image:
                source: "Doc/alg17.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n[b]Rationalizing the Denominator or the Numerator[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nIf a fraction has a denominator of the form A + B square root of C, we may rationalize the denominator by multiplying numerator and denominator by the conjugate radical A - B square root of C. This works because, by Special Product Formula, the product of the denominator and its conjugate radical does not contain a radical:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.70, 'left': 0.70}
            Image:
                source: "Doc/alg18.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalg5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalg7'

<ScreenAlg7>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.35, 'left': 1.35}
            Image:
                source: "Doc/alg19.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1, 'left': 1}
            Image:
                source: "Doc/alg20.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalg6'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen2'

<ScreenEquate>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('An equation is a statement that two mathematical expressions are equal. For example,')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n3 + 5 = 8')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\nis an equation. Most equations that we study in algebra contains variables, which are symbols (using letters) that stand for numbers. In the equation')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n4x + 7 = 19')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\nthe letter x is the variable. We think of x as the unknown in the \"equation\", and our goal is to find the value of x that makes the equation true. The values of the unknown that make the equation true are called the solutions or roots of the equation, andt the process of finding the solutions is called solving the equation.\nTwo equations with exactly the same solutions are called equivalent equations. To solve an equation, we try to find a simpler, equivalent equation in which the variable stands alone on one side of the \"equal\" sign. Here are the properties that we use to solve an equation.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.75, 'left': 0.75}
            Image:
                source: "Doc/equate.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
        
        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenequate1'

<ScreenEquate1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('These properties require that you perform the same operation on both sides of an equation when solving it. Thus, if we say \"add -7\" when solving an equation, that is just a short way of saying \"add -7 to each side of the equation.\"')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n[b]Solving Linear Equations[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\nThe simplest type of equation is linear equation, or first-degree equation, which is an equation in which each term is either a constant or a non-zero multiple of the variable.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.125, 'left': 1.125}
            Image:
                source: "Doc/equate1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHere are some examples that illustrate the difference between linear and nonlinear equations.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.86, 'left': 0.86}
            Image:
                source: "Doc/equate2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nSolve the equation 7x - 4 = 3x + 8')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenequate'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenequate2'

<ScreenEquate2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.36, 'left': 1.36}
            Image:
                source: "Doc/equate3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n[b]Solving Quadratic Equations[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\nLinear equations are first-degree equations like 2x + 1 = 5 or 4 - 3x = 2. Quadratic equations are second-degree equations like x^2 + 2x - 3 = 0 or 2x^2 + 3 = 5x.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nSome quadratic equations can be solved by factoring and using the following basic properties of real numbers.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThis means that if we can factor the left-hand side of a quadratic (or other) equation, then we can solve it by setting each factor equal to 0 in turn. This method works only when the right-hand side of the equation is 0.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.95, 'left': 0.95}
            Image:
                source: "Doc/equate4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.75, 'left': 0.75}
            Image:
                source: "Doc/equate5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenequate1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenequate3'

<ScreenEquate3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Example:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nSolve the equation x^2 + 5x = 24.')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.30, 'left': 1.30}
            Image:
                source: "Doc/equate6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.14, 'left': 1.14}
            Image:
                source: "Doc/equate7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nSolve each equation')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n(a) x^2 = 5\n(b) (x - 4)^2 = 5')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.8, 'left': 0.8}
            Image:
                source: "Doc/equate8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenequate2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenequate4'

<ScreenEquate4>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('As we saw on the example awhile ago, if a quadratic equation is of the form (x plus or minus a)^2 = c, then we can solve it by taking the square root of each side. In an equation of this form the left-hand side is a perfect square: the square of a linear expression in x. So if a quadratic equation does not factor readily, then we can solve it using the technique of completing the square. This means that we add a constant to an expression to make it a perfect square. For example, to make x^2 - 6x a perfect square, we must add 9, since x^2 - 6x + 9 = (x - 3)^2.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.15, 'left': 1.15}
            Image:
                source: "Doc/equate9.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nSolve each equation')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n(a) x^2 - 8x + 13 = 0\n(b) 3x^2 - 12x + 6 = 0')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.75, 'left': 0.75}
            Image:
                source: "Doc/equate10.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenequate3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenequate5'
    
<ScreenEquate5>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('(b) After subtracting 6 from each side of the equation, we must factor the coefficient of x^2 (the 3) from the left side to put the equation in correct form for completing the square.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n3x^2 - 12x + 6 = 0   Given equation\n3x^2 -12x = -6   Subtract 6\n3(x^2 - 4x) = -6   Factor 3 from LHS')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\nNow we complete the square by adding (-2)^2 = 4 inside the parentheses. Since everything inside the parentheses is multiplied by 3, this means that we are actually adding 3 * 4 = 12 to the left side of the equation. Thus, we must add 12 to the right side as well.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.03, 'left': 1.03}
            Image:
                source: "Doc/equate11.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nWe can use the technique of completing the square to derive a formula for the roots of the general quadratic equation ax^2 + bx + c = 0.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.73, 'left': 0.73}
            Image:
                source: "Doc/equate12.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenequate4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenequate6'

<ScreenEquate6>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Find the solution of the equation')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n(a) 3x^2 - 5x - 1 = 0\n(b) 4x^2 + 12x + 9 = 0')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.11, 'left': 1.11}
            Image:
                source: "Doc/equate13.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenequate5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screen2'

<ScreenFunction>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Function All Around Us[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\nIn nearly every physical phenomenon we observe that one quantity depends on another. For example, your height depends on your age, the temperature depends on the date, the cost of mailing a package depends on its weight. We use the term function to describe this dependence of one quantity to another. That is, we say the following:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n- Height is a function of age.\n- Temperature is a function of date.\n- Cost of mailing a package is a function of weight.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe U.S. Post Office uses a simple rule to determine the cost mailing of a first-class parcel on the basis of its weight. But it is not easy to describe the rule that relates height to age or the rule that relates temperature to date.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nCan you think of other examples? Here are some more examples:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n- The area of a circle is a function of its radius.\n- The number of bacteria in a culture is a function of time.\n- The weight of an astrounaut is a function of her elevation.\n- The price of a commodity is a function of the demand for that commodity.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Definition of Function[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nA function is a rule. To talk about a function, we need to give it a name. We will use letters such as f, g, h,.... to represent functions. For example, we can use the letter f to represent a rule as follows:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\"f\" is the rule \"square the number\"')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenfunction1'

<Screenfunction1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('When we write f(2), we mean \"apply the rule of f to the number 2\". Applying the rule gives f(2) = 2^2 =4. Similarly, f(3) = 3^2 = 9, f(4) = 4^2 = 16, and in general f(x) = x^2.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.35, 'left': 1.35}
            Image:
                source: "Doc/function.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\nWe usually consider functions for which the sets A and B are sets of real numbers. The symbol f(x) is read \"f of x\" or \"f at x\" and is called the value of f at x, or the image of x under f. The set A is called the domain of the function. The range of f is the set of all possible values of f(x) as x varies throughout the doamin, that is, ')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.109, 'left': 1.109}
            Image:
                source: "Doc/function1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe symbol that represents an arbitrary number in the domain of a function f is called an independent variable. The symbol that represents a number in the range of f is called a dependent variable. So if we write y = f(x), then x  is the independent variable and y is the dependent variable.\nIt is helpful to think of a function as a machine. If x is in the domain of the function f, then when x enters the machine, it is accepted as an input and the machine procedures an output f(x) according to the rule of the function. Thus, we can think of the domain as the set of all possible inputs and the range as the set of all possible outputs.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nA function f is defined by the formula')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nf(x) = x^2 + 4')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenfunction'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenfunction2'

<Screenfunction2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('(a) Express in words how f acts on the input x to produce the output f(x).\n(b) Evaluate f(3) and f(-2).')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\nSolution:\n(a) The formula tells us that f first squares the input x and then adds 4 to the result. So f is the function')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\"square, then add 4\"')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n(b) The values of f are found by substituting for x in the formula f(x) = x^2 + 4.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\nf(3) = 3^2 + 4 = 13   Replace x by 3\nf(-2) = (-2)^2 + 4 = 8   Replace x by -2')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n[b]Evaluating a Function[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nIn the definition of a function the independent variable x plays the role of a placeholder. For example, the function f(x) = 3x^2 + x - 5 can be thought as')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nf(?) = 3 * (?)^2 + ? - 5')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nTo evaluate f at a number, we substitute the number for the placeholder.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample: Let f(x) = 3x^2 + x - 5. Evaluate each function value.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n(a) f(-2)   (b) f(0)   (c) f(4)   (d) f(1/2)')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenfunction1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenfunction3'

<ScreenFunction3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.385, 'left': 1.385}
            Image:
                source: "Doc/function2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.05, 'left': 1.05}
            Image:
                source: "Doc/function3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Four Ways to represent a Function[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nTo help us understand what a function is, we have used machine and arrow diagrams. We can describe a specific function in the following four ways:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenfunction2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenfunction4'

<ScreenFunction4>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('- Verbally   (by a description in words)\n- Algebraically   (by an explicit formula)\n- Visually   (by a graph)\n- Numerically   (by a table of values)')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\nA single function may be represented in all four ways, and it is often useful to go from one representation to another to gain insight into the function. However, certain functions are described more naturally by one method than by the others. An example of a verbal description is the following rule for converting between temperature scales:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\"To find the Fahrenheit equivalent of a Celcius temperature, multiply the Celcius temperature by 9/5, then add 32\"')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nWe see how to describe the verbal rule or function algebraically, graphically and numerically. A useful representation of the area of a circle as a function of its radius is the algebraic formula')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nA(r) = pi * r^2')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe graph produce by a seismograph is a visual representation of the vertical acceleration function a(t) of the ground during an earthquake. As a final example, consider the function C(w), which is described verbally as \"the cost of mailing a first-class letter with weight w.\" The most convenient way of describing this function is numerically - that is, using a table of values.\nWe will be using all four representations of functions in this summarize box.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True
                
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenfunction3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenfunction5'

<ScreenFunction5>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.3, 'left': 1.3}
            Image:
                source: "Doc/function4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.8, 'left': 0.8}
            Image:
                source: "Doc/function5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenfunction4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenfunction6'

<ScreenFunction6>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.25, 'left': 1.25}
            Image:
                source: "Doc/function6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.80, 'left': 0.80}
            Image:
                source: "Doc/function7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenfunction5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp1'

<ScreenPoly>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Functions defined by polynomial expressions are called polynomial functions. The graphs of polynomial functions can have many peaks and valleys; this makes them suitable models for many real-world situations. For example, a factory owner notices that if she increases the number of workers, productivity increases, but if there are too many workers, productivity begins to decrease. This situation is modeled by a polynomial function of degree 2 (a quadratic function). As another example, when a volleyball is hit, it goes up and then down, following a path that is also modeled by a quadratic function. The graphs of polynomial functions are smooth curves that are used in designing many things. For example, sailboat designers put together portions of the graphs of different cubic functions (called cubic splines) to make the curves of the hull of a sailboat.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n[b]Quadratic Functions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nA polynomial function is a function that is defined by a polynomial expression. So a polynomial function of degree n is a function of the form')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.9, 'left': 0.9}
            Image:
                source: "Doc/poly.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nWe have already studied polynomial functions of degree 0 and 1. These are functions of the form P(x) = a subscript 0 and P(x) = a subscript 1 * x + a subscript 0, respectively, whose graphs are lines. In this section we study polynomial functions of degree 2. These are called quadratic functions.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.66, 'left': 0.66}
            Image:
                source: "Doc/poly1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly1'

<ScreenPoly1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Graphing Quadratic Functions Using the Standard Form[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.2299, 'left': 1.2299}
            Image:
                source: "Doc/poly2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample:\nLet f(x) = 2x^2 - 12x +23\n\n(a) Express f in standard form\n(b) Sketch the graph of f.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nSolution:\n(a) Since the coefficient of x^2 is not 1, we must factor this coefficient from the terms involving x before we complete the square.\n\nf(x) = 2x^2 - 12x + 23\n= 2(x^2 - 6x) + 23   Factor 2 from the x-terms\n= 2(x^2 - 6x + 9) + 23 - 2 * 9   Complete the square: Add 9 inside parentheses, subtract 2 * 9 outside\n = 2(x - 3)^2 + 5   Factor and simplify')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly2'

<ScreenPoly2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('The standard form is f(x) = 2(x - 3)^2 + 5')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n(b) The standard form tells us that we get the graph of f by taking the parabola y = x^2, shifting it to the right 3 units, stretching it by a factor of 2, and moving it upward 5 units. The vertex of the parabola is at (3, 5), and the parabola opens upward. We sketch the graph in Figure 1 after noting that the y-intercept is f(0) = 23.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.1, 'left': 1.1}
            Image:
                source: "Doc/poly3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Maximum and Minimum Values of Quadratic Functions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nIf a quadratic function has vertex (h, k), then the function has a minimum value at the vertex if its graph opens upward and a maxmimum value at the vertex if its graph opens downward. For example, the function graphed in Figure 1 has minimum value 5 when x = 3, since the vertex (3, 5) is the lowest point on the graph.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True
    
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly3'

<ScreenPoly3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.3, 'left': 1.3}
            Image:
                source: "Doc/poly4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nConsider the quadratic function f(x) = 5x^2 - 30x + 49\n\n(a) Express f in standard form.\n(b) Sketch the graph of f.\n(c) Find the minimum value of f.\n\nSolution:\n\n(a)To express this quadratic function in standard form, we complete the square.\n\nQuadratic function = f(x) 5x^2 - 30x + 49\n\n= 5(x^2 - 6x) + 49   Factor 5 from the x-terms\n= 5(x^2 - 6x + 9) + 49 - 5 * 9   Complete the square: Add 9 inside parentheses, subtract 5 * 9 outside\n= 5(x - 3)^2 + 4   Factor and simplify')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly4'

<ScreenPoly4>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('(b) The graph is a parabola that has its vertex at (3, 4) and opens upward, as sketched in Figure 2.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.12, 'left': 1.12}
            Image:
                source: "Doc/poly5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n(c) Since the coefficient of x^2 is positive, f has minimum value. The minimum value is f(3) = 4.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly5'

<ScreenPoly5>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Consider the quadratic function f(x) = -x^2 + x + 2.\n(a) Express f in standard form.\n(b) Sketch the graph of f.\n(c) Find the maximum value of f.\n\nSolution:\n(a) To express this quadratic function in standard form, we complete the square.\n\nQuadratic Function: y = -x^2 + x + 2\n= -(x^2 - x) + 2   Factor -1 from the x-terms\n= -(x^2 - x + 1/4) + 2 - (-1) 1/4   Complete the square: Add 1/4 inside parentheses, subtract (-1)1/4 outside\n= -(x - 1/2)^2 + 9/4   Factor and simplify')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n(b) From the standard form we see that the graph is a parabola that opens downward and has vertex (1/2, 9/4). As an aid to sketching the graph, we find the intercepts. The y-intercepts is f(0) = 2. To find the x-intercepts, we set f(x) = 0 and factor the resulting equation.\n\n-x^2 + x + 2 = 0   Set y = 0\nx-^2 - x - 2 = 0   Multiply by -1\n(x - 2)(x + 1) = 0   Factor\n\nThus the x-intercepts are x = 2 and x = -1. The graph of f is sketched in Figure 3.\n\n(c) Since the coefficient of x^2 is negative, f has a maximum value, which is f(1/2) = 9/4.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly6'
    
<ScreenPoly6>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.2, 'left': 1.2}
            Image:
                source: "Doc/poly6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExpressing a quadratic function in standard form helps us sketch its graph as well as to find its maximum and minimum value. If we are interested only in finding the maximum or minimum value, then a formula is available for doing so. This formula is obtained by completing the square for the general quadratic function as follows:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly7'

<ScreenPoly7>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.38, 'left': 1.38}
            Image:
                source: "Doc/poly7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\nThis equation is in standard form with h = -b/(2a) and k = c - b^2/(4a). Since the maximum and minimum value occurs at x = h, we have  the following result.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.02, 'left': 1.02}
            Image:
                source: "Doc/poly8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample:\nFind the maximum or minimum value of each quadratic function.\n(a) f(x) = x^2 + 4x\n(b) g(x) = -2x^2 + 4x - 5')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly6'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly8'
    
<ScreenPoly8>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.3, 'left': 1.3}
            Image:
                source: "Doc/poly9.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.90, 'left': 0.90}
            Image:
                source: "Doc/poly10.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly7'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly9'
    
<ScreenPoly9>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.3, 'left': 1.3}
            Image:
                source: "Doc/poly11.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpoly8'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp1'

<ScreenExpo>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Introduction to Exponential and Logarithmic Functions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nIn this chapter we study a class of functions called exponential functions. These are fuctions, like f(x) = 2^x, where the independent variable is in the exponent. Exponential functions are used in modeling many real-world phenomenon, such as the growth of a population or the growth of an investment that earns compound interest. Once an exponential model is obtained, we can use the model to predict population size or calculate the amount of an investment for any future date. To find out when a population will reach a certain level, we use the inverse functions of exponential functions, called logarithmic functions. So if we have an exponential model for populaton growth, we can answer questions like: When will my city be as crowded as the New York City street pictured above?')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.2, 'left': 1.2}
            Image:
                source: "Doc/expo.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenexpo1'

<ScreenExpo1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('In this chapter we study a new class of functions called exponential functions. For example,')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\nf(x) = 2^x')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\nis an exponential function (with base 2). Notice how quickly the values of this function increase:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\nf(3) = 2^3 = 8\nf(10) = 2^10 = 1024\nf(30) = 2^30 = 1,073,741,824')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\nCompare this with the function g(x) = x^2, where g(30) = 30^2 = 900. The point is that when the variable is in the exponent, even a small change in the variable can cause a dramatic change in the value of the function.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n[b]Exponential Functions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nTo study exponential functions, we must first define what we mean by the exponential expression a^x when x is real number. We defined a^x for a > 0 and x is a rational number, but we have not yet defined irrational powers. So what is meant by 5 raise to square root of 3 or 2 raise to pi? To define a^x when x is irrational, we approximate x by rational numbers. For example, since')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.78, 'left': 0.78}
            Image:
                source: "Doc/expo1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nis an irrational number, we successively approximate a raise to square root of 3 by the following powers:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.65, 'left': 0.65}
            Image:
                source: "Doc/expo2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenexpo'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenexpo2'

<ScreenExpo2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Intuitively, we can see that these rational powers of a are getting closer and closer to a raise to square root of 3. It can be shown by using an advanced mathematics that there is exactly one number that these powers approach. We define a raise to square root of 3to be his number. For example, using a calculator, we find')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.315, 'left': 1.315}
            Image:
                source: "Doc/expo3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\nThe more decimal places of square root of 3 we use in calculation, the better our approximation of 5 square root of 3.\n\nIt can be proved that the Laws of Exponents are still true when the exponents are real numbers.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.035, 'left': 1.035}
            Image:
                source: "Doc/expo4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nWe assume that a is not equal to 1 because the function f(x) = 1^x = 1 is just a constant function. Here are some examples of exponential functions:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.77, 'left': 0.77}
            Image:
                source: "Doc/expo5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenexpo1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenexpo3'

<ScreenExpo3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.35, 'left': 1.35}
            Image:
                source: "Doc/expo6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n[b]Graphs of Exponential Functions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\nWe first graph exponential functions by plotting ponits. We will see that the graphs of such functions have an easily recognizable shape.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.81, 'left': 0.81}
            Image:
                source: "Doc/expo7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenexpo2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenexpo4'

<ScreenExpo4>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Notice that')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.41, 'left': 1.41}
            Image:
                source: "Doc/expo8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\nso we could have obtained the graph of g from the graph of f by reflecting in the y-axis.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\nFigure 2 shows the graphs of the family of exponential functions f(x) = a^x for various values of the base a. All of these graph pass through the point (0, 1) because a ^0 = 1 for a is not equal to 0. You can see from Figure 2 that there are two kinds of exponential functions: If a is greater than 0 but less than 1, the exponential function decreases rapidly. If a is greater than 1, the function increases rapidly (see the margin note).')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.82, 'left': 0.82}
            Image:
                source: "Doc/expo9.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenexpo3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenexpo5'

<ScreenExpo5>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.44, 'left': 1.44}
            Image:
                source: "Doc/expo10.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.2, 'left': 1.2}
            Image:
                source: "Doc/expo11.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenexpo4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalgo'

<ScreenAlgo>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Logarithmic Functions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nEvery exponential function f(x) = a^x, with a is greater than 0 and a is not equal to 1, is a one-to-one function by the Horizontal Line Test (see Figure 1 for the case a is greater than 1) and therefore has an inverse function. The inverse function f^-1 is called the logarithmic function with a base a and is denoted by log subscript a.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.05, 'left': 1.05}
            Image:
                source: "Doc/algo.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThis leads to the following definition of the logarithmic function.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.69, 'left': 0.69}
            Image:
                source: "Doc/algo1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenexpo5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalgo1'

<ScreenAlgo1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('When we use the definition of logarithms to switch back and forth between the logarithmic form log subscript a multiply by x = y and the exponential form a^y = x, it is helpful to notice that, in both forms the base is the same:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.24, 'left': 1.24}
            Image:
                source: "Doc/algo2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe logarithmic and exponential forms are equivalent equations: If one is true, then so is the other. So we can switch from one form to the other as in the following illustrations.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.87, 'left': 0.87}
            Image:
                source: "Doc/algo3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nIt is important to understand that log subscript a multiply by x is an exponent. For example, the numbers in the right column of the table in the margin are the logarithms (base 10) of the numbers in the left column. This is the case for all bases, as the following example illustrates.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalgo'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalgo2'

<ScreenAlgo2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.4, 'left': 1.4}
            Image:
                source: "Doc/algo4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.2, 'left': 1.2}
            Image:
                source: "Doc/algo5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.05, 'left': 1.05}
            Image:
                source: "Doc/algo6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Graphs of Logarithmic Functions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.705, 'left': 0.705}
            Image:
                source: "Doc/algo7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalgo1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalgo3'

<ScreenAlgo3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.2, 'left': 1.2}
            Image:
                source: "Doc/algo8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample:\nSketch the graph of f(x) = log subscript 2 multiply by x\n\nSolution\nTo make a table of values, we choose the x-values to be powers of 2 so that we can easily find their logarithms. We plot these points and connect them with a smooth curve as in Figure 3.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalgo2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalgo4'

<ScreenAlgo4>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.3, 'left': 1.3}
            Image:
                source: "Doc/algo9.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\nFigure 4 shows the graphs of the family of logarithmic functions with bases 2, 3, 5, and 10. These graphs are drawn by reflecting the graphs of y = 2^x, y = 3^x, y = 5^x and y = 10^x in the line y = x.\nFigure 4. A family of logarithmic functions')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.78, 'left': 0.78}
            Image:
                source: "Doc/algo10.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalgo3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalgo5'

<ScreenAlgo5>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Common Logarithms[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nWe now study logarithms with base 10.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\nFrom the definition of logarithms we can easily find that')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\nlog 10 = 1     and     log 100 = 2')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\nBut how do we find log 50? We need to find the exponent y such that 10^y = 50. Clearly, 1 is too small and 2 is too large. So')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n1 < log 50 <  2')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nTo get a better approximation, we can experiment to find a power of 10 closer to 50. Fortunately, scientific calculators are equipped with a LOG key that directly gives values of common logarithms.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Natural Logarithms[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.34, 'left': 1.34}
            Image:
                source: "Doc/algo11.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.75, 'left': 0.75}
            Image:
                source: "Doc/algo12.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalgo5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalgo6'

<ScreenAlgo6>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.2, 'left': 1.2}
            Image:
                source: "Doc/algo13.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe natural logarithmic function y = ln x is the inverse function of the natural exponential function y = e^x. Both functions are graphed in Figure 9. By the definition of inverse functions we have')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.7, 'left': 0.7}
            Image:
                source: "Doc/algo14.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalgo5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalgo7'

<ScreenAlgo7>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.4, 'left': 1.4}
            Image:
                source: "Doc/algo15.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n[b]Laws of Logarithms[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\nSince logarithms are exponents, the Law of Exponents give rise to the Laws of Logarithms.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.06, 'left': 1.06}
            Image:
                source: "Doc/algo16.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.78, 'left': 0.78}
            Image:
                source: "Doc/algo17.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenalgo6'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp1'

<ScreenUnit>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('The Unit Circle')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nThe set of points at a distance 1 from the origin is a circle of radius 1 (see Figure 1).')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.2, 'left': 1.2}
            Image:
                source: "Doc/unit.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.95, 'left': 0.95}
            Image:
                source: "Doc/unit1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample: A Point on the Unit Circle')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.73, 'left': 0.73}
            Image:
                source: "Doc/unit2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenunit1'

<ScreenUnit1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Example: Locating a Point on the Unit Circle')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.32, 'left': 1.32}
            Image:
                source: "Doc/unit3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('[b]\n\n\n\n\n\n\n\nTerminal Points on the Unit Circle[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nSuppose t is a real number. Let\'s mark off a distance t along the unit circle, starting at the point (1, 0) and moving in a counterclockwise direction if t is positive or in a clockwise direction if t is negative (figure below). In this way we arrive at a point P(x, y) on the unit circle. The point P(x, y) obtained in this way is called terminal point determined by the real number t.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.75, 'left': 0.75}
            Image:
                source: "Doc/unit4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenunit'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenunit2'

<ScreenUnit2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('The circumference of the unit circle is C = 2(pi)(1) = 2pi. So if a point starts at (1, 0) and moves conterclockwise all the way around the unit circle and returns to (1, 0), it travels a distance of 2pi. To move halfway around the circle, it travels a distance of 1/2(2pi) = pi. To move a quarter of the distace around the circle, it travels a distance of 1/4(2pi) = pi/2. Where does the point end up when it travels these distances along the circle? From the figure below, we see, for example, that when it travels a distance of pi starting at (1, 0), its terminal point is (-1, 0).')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.17, 'left': 1.17}
            Image:
                source: "Doc/unit5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('[b]\n\n\n\n\n\n\n\n\n\nThe Trigonometric Functions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nRecall that to find the terminal point P(x, y) for a given real number t, we move a distance t along the unit circle, starting at the point (1, 0). We move in a counterclockwise direction if t is positive and in a clockwise direction if t is negative (see figure in the next page). We now use the x-axis and y-coordinates of the point P(x, y) to define several functions. For instance, we define the function called sine by assigning to each real number t the coordinate y-coordinate of the terminal point P(x, y) determined by t. The functions cosine, tangent, cosecant, secant, and cotangent are also defined by using the coordinates of P(x, y).')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenunit1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenunit3'

<ScreenUnit3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.3, 'left': 1.3}
            Image:
                source: "Doc/unit6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1, 'left': 1}
            Image:
                source: "Doc/unit7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nBecause the trigonometric functions can be defined in terms of the unit circle, they are sometimes called the circular functions.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenunit2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenunit4'

<ScreenUnit4>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Example: Evaluating Trigonometric Functions')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.4, 'left': 1.4}
            Image:
                source: "Doc/unit8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.25, 'left': 1.25}
            Image:
                source: "Doc/unit9.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.97, 'left': 0.97}
            Image:
                source: "Doc/unit10.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.7, 'left': 0.7}
            Image:
                source: "Doc/unit11.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenunit3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenunit5'

<ScreenUnit5>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Some special values of the trigonometric functions are listed in the table below.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.27, 'left': 1.27}
            Image:
                source: "Doc/unit12.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('[b]Trigonometric Identities[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenunit4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp1'

<ScreenGeo>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.25, 'left': 1.25}
            Image:
                source: "Doc/analytic.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Simplifying Trigonometric Expressions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nIdentities enable us to write the same expression in different ways. It is often possible to rewrite a complicated-looking expression as a much simpler one. To simplify algebraic expressions, we used factoring, common denominators, and the Special Product Formulas. To simplify trigonometric expressions, we use these same techniques together with the funcdamental trigonometric identities.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screengeo1'

<ScreenGeo1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Example: Simplifying A Trigonometric Expression\nSimplify the expression cos t + tan t sin t.\n\nSolution:\nWe start by rewriting the expression in terms of sine and cosine:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.22, 'left': 1.22}
            Image:
                source: "Doc/analytic1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample: Simplifying by Combining Fractions')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.85, 'left': 0.85}
            Image:
                source: "Doc/analytic2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screengeo'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screengeo2'

<ScreenGeo2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Proving Trigonometric identities[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nMany identities follow from the fundamental identities. In the examples that follow, we learn how to prove that a given trigonometric equation is an identity, and in the process we will see how to discover new identities.\nFirst, it\'s easy to decide when a given equation is not an identity. All we need to do is show that the equation does not hold for some value of the variable (or variables). Thus the equation')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.22, 'left': 1.22}
            Image:
                source: "Doc/analytic3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\nis not an identity, because when x = pi/4, we have')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.1, 'left': 1.1}
            Image:
                source: "Doc/analytic4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nTo verify that a trigonometric equation is an identity, we transform one side of the equation into the other side by a series of steps, each of which is itself an identity.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.82, 'left': 0.82}
            Image:
                source: "Doc/analytic5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screengeo1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screengeo3'

<ScreenGeo3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Example: Proving an Identity by Combining Fractions')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.4, 'left': 1.4}
            Image:
                source: "Doc/analytic6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\nSolution:\nFinding a common denominator and combining the fractions on the right-hand side of this eqauation, we get')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.03, 'left': 1.03}
            Image:
                source: "Doc/analytic7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample: Proving an Identity by Introducing Something Extra')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.7, 'left': 0.7}
            Image:
                source: "Doc/analytic8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screengeo2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screengeo4'

<ScreenGeo4>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Solution:\nWe start with the left-hand side and multiply the numerator and denominator by 1 + sin u:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.15, 'left': 1.15}
            Image:
                source: "Doc/analytic9.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHere is another method for proving that an equation is an identity. If we can transform each side of the equation separately, by way of identities, to arrive at the same result, then the equation is an identity.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screengeo3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screengeo5'

<ScreenGeo5>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Example: Proving an Identity by Working with Both Sides Separately')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.4, 'left': 1.4}
            Image:
                source: "Doc/analytic10.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\nSolution:\nWe prove the identity by changing each side separately into the same expression. Supply the reasons for each step:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.17, 'left': 1.17}
            Image:
                source: "Doc/analytic11.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nWe conclude this section by describing the technique of trigonometric substitution, which we use to convert algebraic expressions to trigonometric ones. This is often usefu in calculus, for instance, in finding the area of a circle or an ellipse.\n\nExample: Trigonometric Substitution')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.78, 'left': 0.78}
            Image:
                source: "Doc/analytic12.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screengeo4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp1'

<ScreenConic>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Conic sections are the curves we get when we make a straight cut in a cone, as shown in the figure. For example, if a cone is cut horizontally, the cross section is a circle. So a circle is a conic section. Other ways of cutting a cone produce parabolas, ellipses, and hyperbolas.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.2, 'left': 1.2}
            Image:
                source: "Doc/conic.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nOur goal in this chapter is to find equations whose graphs are the conic sections. The conic sections have interesting properties that make them useful for many real-world applications. For instance, a reflecting surface with parabolic cross-sections concentrates light at a single point. This property of a parabola is used in the construction of solar power plants, like the one in California pictured above.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('[b]\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nGeometric Definition of a Parabola[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe U-shaped called parabola that opens either upward or downward, depending on whether the sign of a is positive or negative is called parabola that has the equation:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screengeo4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic1'

<ScreenConic1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('In this section we study parabolas from a geometric rather than an algebraic point of view. We begin with the geometric definition of a parabola and show how this leads to the algebraic formula that we are already familiar with.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.32, 'left': 1.32}
            Image:
                source: "Doc/conic1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\nThis definition is illustrated in Figure 1. The vertex V of the prabola lies halfway between the focus and the directrix, and the axis of symmetry is the line that runs through the focus perpendicular to the directrix.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.915, 'left': 0.915}
            Image:
                source: "Doc/conic2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic2'

<ScreenConic2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('In this section we strict our attention to parabolas that are situated with the vertex at the origin and that have a vertical or horizontal axis of symmetry. If the focus of such a parabola is the point F(0, p), then the axis of symmetry must be vertical, and the directrix has the equation y = -p. Figure 2 illustrates the case p > 0.\nIf P(x, y) is any point on the parabola, then the distance from P to the focus F (using the Distance Formula) is')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.255, 'left': 1.255}
            Image:
                source: "Doc/conic3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\nThe distance from P to the directrix is')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.15, 'left': 1.15}
            Image:
                source: "Doc/conic4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.90, 'left': 0.90}
            Image:
                source: "Doc/conic5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic3'

<ScreenConic3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('By the definition of a parabola these two distances must be equal:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.32, 'left': 1.32}
            Image:
                source: "Doc/conic6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\nIf p > 0, then the parabola opens upward; but if p < 0, it opens downward. When x is replaced by -x, the equation remains unchanged, so the graph is symmetric about the y-axis.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n[b]Equations and Graphs of Parabola[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe following box summarizes what we have just proved about the equation and features of a parabola with a vertical axis.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.8, 'left': 0.8}
            Image:
                source: "Doc/conic7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic4'

<ScreenConic4>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.35, 'left': 1.35}
            Image:
                source: "Doc/conic8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\nExample: Finding the Equation of a Parabola\nFind an equation for the parabola with vertex V(0,0) and focus F(0,2), and sketch its graph.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1, 'left': 1}
            Image:
                source: "Doc/conic9.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.75, 'left': 0.75}
            Image:
                source: "Doc/conic10.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic5'

<ScreenConic5>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Example: Finding the Focus and Directrix of a Parabola from Its Equation\nFind the focus and directrix of the parabola y = -x^2, and sketch the graph.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.32, 'left': 1.32}
            Image:
                source: "Doc/conic11.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.12, 'left': 1.12}
            Image:
                source: "Doc/conic12.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nReflecting the graph in Figure 2 about the diagonal line y = x has the effect of interchanging the roles of x and y. This results in a parabola with horizontal axis. By the same method as before, we can prove the following properties.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic6'

<ScreenConic6>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.22, 'left': 1.22}
            Image:
                source: "Doc/conic13.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample: A Parabola with Horizontal Axis\nA parabola has the equation 6x + y^2 = 0. Find the focus and directrix of the parabola, and sketch the graph.\n\nSolution:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.7, 'left': 0.7}
            Image:
                source: "Doc/conic14.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic7'

<ScreenConic7>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.25, 'left': 1.25}
            Image:
                source: "Doc/conic15.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample: The Focal Diameter of a Parabola\nFind the focus, directrix, and focal diameter of the parabola y = 1/2x^2, and sketch its graph.\n\nSolution: We first put the equation in the form x^2 = 4py.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.75, 'left': 0.75}
            Image:
                source: "Doc/conic16.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic6'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic8'

<ScreenConic8>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02
       
        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.233, 'left': 1.233}
            Image:
                source: "Doc/conic17.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Applications[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nParabolas have an important property that makes them useful as reflectors for lamps and telescopes. Light from a source placed at the focus of a surface with parabolic cross section will be reflected in such a way that it travels parallel to the axis of the parabola (see the next figure). Thus, a parabolic minor reflects the light into a beam of parallel rays. Conversely, light approaching the reflector in rays parallel to its axis of symmetry is concentrated to the focus. This reflection property, which can be proved by using calculus, is used in the construction of reflecting telescopes.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic7'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic9'

<ScreenConic9>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.233, 'left': 1.233}
            Image:
                source: "Doc/conic18.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic8'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic10'

<ScreenConic10>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Geometric Definition of an Ellipse[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nAn ellipse is an oval curve that looks like an elongated circle. More precisely, we have the following definition.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.32, 'left': 1.32}
            Image:
                source: "Doc/ellipse.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.11, 'left': 1.11}
            Image:
                source: "Doc/ellipse1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe geometric definition suggests a simple method for drawing an ellipse. Place a sheet of paper on a drawing board, and insert thumbtacks at the two points that are to be the foci of the ellipse. Attach the ends of a string to the tacks, as shown in Figure 2(a). With the point of a pencil, hold the string taut. Then carefully move the pencil around the foci, keeping the string taut at all times. The pencil will trace out an ellipse, because the sum of the distances from the point of the pencil to the foci will always equal the length of the string, which is constant. If the string is only slightly longer than the distance between the foci, then the ellipse that is traced out will be elongated in shape, as in Figure 2(a), but if the foci are close together relative to the length of the string, the ellipse will almost circular, as shown in Figure 2(b).')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic9'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic11'

<ScreenConic11>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.3, 'left': 1.3}
            Image:
                source: "Doc/ellipse2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nTo obtain the simplest equation for an ellipse, we place the foci on the x-axis at F base 1 (-c,0) and F base 2 (c,0) so that the origin is halfway between them (see Figure 3).\nFor later conveniece we let the sum of the distances from a point on the ellipse to the foci be 2a. Then if P(x,y) is any point on the ellipse, we have')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.88, 'left': 0.88}
            Image:
                source: "Doc/ellipse3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nSo from the distance formula we have ')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nor')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nSquaring each side and expanding, we get')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.79, 'left': 0.79}
            Image:
                source: "Doc/ellipse4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.705, 'left': 0.705}
            Image:
                source: "Doc/ellipse5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.605, 'left': 0.605}
            Image:
                source: "Doc/ellipse6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic10'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic12'

<ScreenConic12>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('which simplifies to')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.43, 'left': 1.43}
            Image:
                source: "Doc/ellipse7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\nDividing each side by 4 and squaring again, we get')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.27, 'left': 1.27}
            Image:
                source: "Doc/ellipse8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\nSince the sum of the distances from P to the foci must be larger than the distance between the foci, we have that 2a > 2c, or a > c. Thus a ^2 - c^2 > 0, and we can divide each side of the preceeding equation by a^2(a^2 - c^2) to get')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1, 'left': 1}
            Image:
                source: "Doc/ellipse9.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nFor convenience let b^2 = a2 - c^2 (with b > 0). Since b^2 < a^2, it follows that b < a. The preceeding equation then becomes')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.833, 'left': 0.833}
            Image:
                source: "Doc/ellipse10.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThis is the equation of the ellipse. To graph it, we need to know the x- and y- intercepts. Setting y = 0, we get')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.65, 'left': 0.65}
            Image:
                source: "Doc/ellipse11.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic11'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic13'

<ScreenConic13>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('so x^2 = a^2, or x equals to positive and negative a. Thus, the ellipse crosses the x-axis at (a,0) and (-a,0), as in Figuer 4. These points are called the vertices of the ellipse, and the segment that joins them is called the major axis. Its length is 2a.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.23, 'left': 1.23}
            Image:
                source: "Doc/ellipse12.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nSimilarity, if we set x = 0, we get y = plus and minus b, so the ellipse crosses the y-axis at (0,b) and (0,-b). The segment that joins these points is called the minor axis, and it has length 2b. Note that 2a > 2b, so the major axis is longer than the minor axis. The origin is the center of the ellipse.\nIf the foci of the ellipse are placed on the y-axis at (0, positive and negative c) rather than on the x-axis, then the roles of x and y are reversed in the preceding discussion, and we get a vertical ellipse. ')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Equations and Graphs of Ellipses[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe following box summarizes what we have just proved about the equation and features of an ellipse centered at the origin.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic12'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic14'

<ScreenConic14>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.23, 'left': 1.23}
            Image:
                source: "Doc/ellipse13.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample: Sketching An Ellipse\nAn ellipse has the equation\n\nx^2/9 + y^2/4 = 1\n\n(a) Find the foci, the vertices, and the lengths of the major and minor axes, and sketch the graph.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic13'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic15'

<ScreenConic15>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Solution:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.33, 'left': 1.33}
            Image:
                source: "Doc/ellipse14.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1, 'left': 1}
            Image:
                source: "Doc/ellipse15.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic14'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic16'

<ScreenConic16>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Example: Find the Foci of an Ellipse\nFind the foci of the ellipse 16x^2 + 9y^2 = 144, and sketch its graph.\n\nSolution:\nFirst we put the equation in standard form. Dividing by 144, we get\n\nx^2/9 +y^2/16 = 1.\n\nSince 16 > 9, this is an ellipse with its foci on the y-axis and with a = 4 and b = 3.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.07, 'left': 1.07}
            Image:
                source: "Doc/ellipse16.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.87, 'left': 0.87}
            Image:
                source: "Doc/ellipse17.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic15'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic17'

<ScreenConic17>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Geometric Definition of a Hyperbola[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nAlthough ellipses and hyperbolas have completely different shapes, their definitions and equations are similar. Instead of using the sum of distances from two fixed foci, as in the case of an ellipse, we use the difference to define a hyperbola.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.26, 'left': 1.26}
            Image:
                source: "Doc/ellipse18.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.98, 'left': 0.98}
            Image:
                source: "Doc/ellipse19.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.675, 'left': 0.675}
            Image:
                source: "Doc/ellipse20.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic16'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic18'

<ScreenConic18>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('x^2/a^2 - y^2/b^2 = 1')
                halign: 'center'
                font_size:16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nThis is the equation of the hyperbola. If we replace x by -x or y by -y in this equation, it remains unchanged, so the hyperbola is symmetric about both the x- and y-axes and about the origin. The x-intercepts are positive and negative a and the points (a,0) and (-a,0) are the vertices of the hyperbola. There is no y-intercept, because setting x = 0 in the equation of the hyperbola leads to -y^2 = b^2, which has no real solution. Furthermore, the equation of the hyperbola implies that')
                halign: 'left'
                font_size:16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\nx^2/a^2 = y^2/b^2 + 1 greater than or equal to 1')
                halign: 'center'
                font_size:16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\nso x^2/a^2 greater than or equal to 1; thus x^2 greater than or equal to a^2, and hence x greater than or equal to a or x is less than or equal to -a. This means that the hyperbola consists of two parts, called its branches. The segment joining two vertices on the separate branches is the tranverse axis of the hyperbola, and the origin is called its center.\nIf we place the foci of the hyperbola on the y-axis rather than on the x-axis, this has the effect of reversing the roles of x and y in the derivation of the equation of the hyperbola. This leads to a hyperbola with a vertical transverse axis.')
                halign: 'left'
                font_size:16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Equations and Graphs of Hyperbolas[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe main properties of hyperbolas are listed in the following box at the next page.')
                halign: 'left'
                font_size:16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic17'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic19'

<ScreenConic19>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.26, 'left': 1.26}
            Image:
                source: "Doc/ellipse21.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe asymptotes metioned in this box are lines that the hyperbola approaches for large values of x and y. To find the asymptotes in the first case in the box, we solve the equation for y to get')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.84, 'left': 0.84}
            Image:
                source: "Doc/ellipse22.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic18'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic20'

<ScreenConic20>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.32, 'left': 1.32}
            Image:
                source: "Doc/ellipse23.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.025, 'left': 1.025}
            Image:
                source: "Doc/ellipse24.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.75, 'left': 0.75}
            Image:
                source: "Doc/ellipse25.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic19'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic21'

<ScreenConic21>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Example: A Hyperbola with Horizontal Transverse Axis')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nA hyperbola has the equation 9x^2 - 16y^2 = 144\n\n(a) Find the vertices, foci, and asymptotes, and sketch the graph.\n\nSolution')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.14, 'left': 1.14}
            Image:
                source: "Doc/ellipse26.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.85, 'left': 0.85}
            Image:
                source: "Doc/ellipse27.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic20'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic22'

<ScreenConic22>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Example: A Hyperbola with Vertical Transverse Axis')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nFind the vertices, foci, and asymptotes of the hyperbola, and sketch its graph.\n\nx^2 - 9y^2 + 9 = 0\n\nSolution:\nWe begin by writing the equation in the standard form for a hyperbola.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\nx^2 - 9y^2 = -9\ny^2 - x^2/9 = 1   Divide by -9')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.875, 'left': 0.875}
            Image:
                source: "Doc/ellipse28.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenconic21'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp1'

<ScreenIntro>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('\n\n[b]Introduction[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\nThis doesn\'t cover all topics of the basic calculus but the mere importance of atleast some topics.\n\nIn calculus, limit is a fundamental concept and intuitive idea is introduced. It is used when we consider differentiation (to define derivatives) and integration (to define intergrals). There are many types of limits. Students should notice that their definitions are similar.\n\nBasic concepts and applications of differentiation are discussed. Students who know how to work on limits of functions at a point should be able to apply definition to find derivatives of "simple" functions.\n\nMoreover, more formulas for differentiation, formulas for the derivatives of the sine, cosine, and tangent functions as well as that of the logarithmic and exponentials functions are given.\n\nStudents should bear in mind that the main purpose of learning calculus is not just knowing how to perform differentiation and integration but also knowing how to apply differentiation and integration to solve problems. For that, one must understand the concepts. To perform calculation, we can use calculators or computer softwares, like Mathematica, Maple or Matlab.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True
        
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp3'

<ScreenLimit>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Definition of Sequence[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nA sequence is..')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.393, 'left': 1.393}
            Image:
                source: "Doc/sequence.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\nA sequence of real numbers is..')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.3, 'left': 1.3}
            Image:
                source: "Doc/sequence1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.25, 'left': 1.25}
            Image:
                source: "Doc/sequence2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\nRemember, for each positive integer n, the value f(n) is called the nth term of the sequence and is usually denoted by a small letter together with n in the subscript, for example is a subscript n. The sequence is denoted by (a subscript n)^infinity subscript of the whole value is n = 1 because if we know all the a subcript n\'s, then we know the sequence.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.01, 'left': 1.01}
            Image:
                source: "Doc/sequence3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample: (3.2.1) and (3.2.2)')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.85, 'left': 0.85}
            Image:
                source: "Doc/sequence4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.7, 'left': 0.7}
            Image:
                source: "Doc/sequence5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenlimit1'

<ScreenLimit1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('It is not a good way to describe a sequence by listing a few terms in the sequence. For example, in (3.2.1) and (3.2.2), it may not be easy to find a formula for the nth term. Moreover, different people may obtain different formulas. It is better to describe a sequence by writing down a formula for the nth term explicitly.\n\nTo denote a sequence..')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.28, 'left': 1.28}
            Image:
                source: "Doc/sequence6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n[b]Rules for Limits of Sequences[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n(L1)\n\n\n(L2)\n\n\n(L3)\n\n\n(L4)\n\n\n(L5)')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1, 'left': 1}
            Image:
                source: "Doc/sequence7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.92, 'left': 0.92}
            Image:
                source: "Doc/sequence8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.84, 'left': 0.84}
            Image:
                source: "Doc/sequence9.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.76, 'left': 0.76}
            Image:
                source: "Doc/sequence10.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.68, 'left': 0.68}
            Image:
                source: "Doc/sequence11.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenlimit'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenlimit2'

<ScreenLimit2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('(L6)')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.42, 'left': 1.42}
            Image:
                source: "Doc/sequence12.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenlimit1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp3'

<ScreenLimit3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]One-sided Limits[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nWe consider limits at a point a on the real line by letting x approach a. Because x can approach a from the left-side or from the right-side, we have left-side and right-side limits. They are called one-sided limits.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n[b]Right-side Limits[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\nDefinition:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.19, 'left': 1.19}
            Image:
                source: "Doc/sided.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.12, 'left': 1.12}
            Image:
                source: "Doc/sided1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.05, 'left': 1.05}
            Image:
                source: "Doc/sided2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nRemember:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe condition \'\'f(x) is defined for x sufficiently close to and greater than a\'\' means that there is a positive...')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nFor simplicity, instead of saying the condition, we will say \'\'f is defined on the right-side of a\'\'.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nIn the definition, it doesn\'t matter whether f is defined at a or not. If f(a) is defined, its value has no effect on the existence and the value of limit of f(x) as x approaches a (positive). This is because right-side limit depends on the values of f(x) for x close to and greater than a.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.875, 'left': 0.875}
            Image:
                source: "Doc/sided3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenlimit4'

<ScreenLimit4>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Example:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.33, 'left': 1.33}
            Image:
                source: "Doc/sided4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.06, 'left': 1.06}
            Image:
                source: "Doc/sided5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.73, 'left': 0.73}
            Image:
                source: "Doc/sided6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenlimit3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenlimit5'

<ScreenLimit5>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.36, 'left': 1.36}
            Image:
                source: "Doc/sided7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.05, 'left': 1.05}
            Image:
                source: "Doc/sided8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.8, 'left': 0.8}
            Image:
                source: "Doc/sided9.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenlimit4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenlimit6'

<ScreenLimit6>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Left-side Limits[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nIf a function f is defined on the left-side of a, we can consider its left-side limit. The notation as limit of f(x) as x approaches a (negative) = L means that f(x) is arbitrarily close to L if x is sufficiently close to and less than a.\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.18, 'left': 1.18}
            Image:
                source: "Doc/sided10.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.93, 'left': 0.93}
            Image:
                source: "Doc/sided11.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenlimit5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenlimit7'

<ScreenLimit7>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.323, 'left': 1.323}
            Image:
                source: "Doc/sided12.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\nReaders can figure out the meaning of the notations themselves. Geometrically, if any one of these notations is true, then the line x = a is a vertical asymptote for the graph of f.\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.86, 'left': 0.86}
            Image:
                source: "Doc/sided13.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenlimit6'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp3'

<ScreenTwoLimit>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Two-sided Limits[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n[b]Definition[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\nLet a all elements (real numbers) and let f be a function that is defined on the left-side and right-side of a. Suppose that both limit of f(x) as x approaches negative a\'s and limit of f(x) as x approaches positive a\'s exist and are equal (with the common limit denoted by L which is a real number). Then the two-sided limit, or more simply, the limit of f at a is defined to be L, written as limit of f(x) as x approches a is equal to L.\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.03, 'left': 1.03}
            Image:
                source: "Doc/twolimits.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.75, 'left': 0.75}
            Image:
                source: "Doc/twolimits1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screentwolimit1'

<ScreenTwoLimit1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Example:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.31, 'left': 1.31}
            Image:
                source: "Doc/twolimits2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.02, 'left': 1.02}
            Image:
                source: "Doc/twolimits3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe following rules are useful to find limits of functions at a point a. In Rules (La4), (La5), (La5s) and (La6), f and g are functions that are defined on the left-side and right-side of a. Some of the rules are similar to that for limits of functions at infinity.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screentwolimit'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screentwolimit2'

<ScreenTwoLimit2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('\n\n\n[b]Rules For Limits of a Function at a Point[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1, 'left': 1}
            Image:
                source: "Doc/twolimits4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screentwolimit1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screentwolimit3'

<ScreenTwoLimit3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Example:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.36, 'left': 1.36}
            Image:
                source: "Doc/twolimits5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.2, 'left': 1.2}
            Image:
                source: "Doc/twolimits6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.9, 'left': 0.9}
            Image:
                source: "Doc/twolimits7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screentwolimit2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp3'

<ScreenContinue>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Continuous Functions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nFor the \'\'nice\'\' functions, we can use substitution to find limits, that is, limit of f(x) as x approaches a is equals to f(a). Functions with this property are called continuous functions. They are very important in the theory of more advanced calculus because they have many other nice properties.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n[b]Definition[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\nLet a (elements are real numbers) and let f be a function such that f(x) is defined for x sufficiently close to a (including a).\nIf the following condition holds, limit of f(x) as x approaches a is equal to f(a), then we say that f is continuous at a. Otherwise, we say that f is discontinuous (or not continuous) at a.\n\nThe condition \'\'f(x) is defined for x sufficiently close to a\'\' means that there exists a positive real number. This condition implies that f is defined on the left-side and right-side of a as well as at the point a. Condition means that the left-side and right-side limits exist and limit of f(x) as x approaches positive a\'s is equal to the limit of f(x) as x approaches negative a\'s is equal to f(a).\n\nCondition can be replaced by the following:\nf(x) is arbitrarily close to f(a) if x is sufficiently close to a.\n\nInstead of saying \'\'f(x) is arbitrarily close to f(a) if x is sufficiently close to a\'\', we will say \'\'f(x) is close to f(a) if x is close to a.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screencontinue1'

<ScreenContinue1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.37, 'left': 1.37}
            Image:
                source: "Doc/continue.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.11, 'left': 1.11}
            Image:
                source: "Doc/continue1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nIf a function f is undefined at a, it is meaningless to talk about whether f is continuous at a. The condition means that\n\n(1) the limit of f(x) as x approaches a exists\n(2)the limit in (1) equals f(a).\n\nIf limit of f(x) as x approaches a does not exist or if limit of f(x) as x approaches a exists but does not equal to f(a), then f discontinuous at a.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screencontinue'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screencontinue2'

<ScreenContinue2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Example:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.39, 'left': 1.39}
            Image:
                source: "Doc/continue2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\nExplanation: The function is defined on the left-side and the right-side of 0 as well as at 0. Therefore, we may consider whether f is continuous at 0. In fact, we may consider, whether f is continuous at 1 etc.. but this is another question.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.1, 'left': 1.1}
            Image:
                source: "Doc/continue3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.9, 'left': 0.9}
            Image:
                source: "Doc/continue4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screencontinue1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screencontinue3'

<ScreenContinue3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Example:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.42, 'left': 1.42}
            Image:
                source: "Doc/continue5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\nExplanation: The domain of f is a real numbers. So we may consider continuity of f at any point a (elements is/are real numbers, that is whether f is continuous at a).\n\nSolution:\nConsider the two cases where a is equal to 0 or a is not equal to 0:\n\n(a = 0)   Note that f(x) = x^2 on the left-side and the right side of 0. Thus we have')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.98, 'left': 0.98}
            Image:
                source: "Doc/continue6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nTherefore, f is not continuous at 0.\n\n(a is not equal to 0)   Note that f(x) = x^2 on the left-side and the right-side of a. Thus we have')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.67, 'left': 0.67}
            Image:
                source: "Doc/continue7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screencontinue2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screencontinue4'

<ScreenContinue4>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Therefore, f is continuous at a.\n\nThe graph of f is shown in Figure 3.22.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.25, 'left': 1.25}
            Image:
                source: "Doc/continue8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screencontinue3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp3'

<ScreenDerivatives>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Derivatives[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nConsider the curve shown Figure 4.1. It is clear from intuition that the \'\'slope\'\' changes as we move along the curve. At P\', the slope is very steep whereas at P, the slope is gentle (in this sentence, slope means a piece of ground going up or down).')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.17, 'left': 1.17}
            Image:
                source: "Doc/derivative.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nIn elementary coordinate geometry, readers have learnt the concept \'\'slope of a line\'\'. It is a number which measures how steep is the line. For a non-vertical line, its slope is given by')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.88, 'left': 0.88}
            Image:
                source: "Doc/derivative1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nwhere (x sub 1, y sub 1) and (x sub 2, y sub 2) are two distinct points on the line and the value is independent of the choice of the two points.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenderivatives1'
    
<ScreenDerivatives1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.33, 'left': 1.33}
            Image:
                source: "Doc/derivative2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\nFor curves, we should not say \'\'slope of a curve\'\' because at different points of the curve, the slopes are different. Instead we should say \'\'slope of a curve at a point\'\'. Below is how we define this concept.\n\nFirst, we have a curve  e and a point P on the curve. To define the slope of e at P, take a point Q on the curve different from P. The line PQ is called a secant line at P. Its slope, denoted by m sub PQ, can be found using the coordinates of P and Q. If we let Q move along the curve, the slope m sub PQ changes.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.73, 'left': 0.73}
            Image:
                source: "Doc/derivative3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True
        
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenderivatives'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenderivatives2'

<ScreenDerivatives2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Suppose that as Q approaches P, the number m sub PQ approaches a fixed value. This value, denoted by m sub e,P or simply m sub P if the curve is understood, is called the slope of e at P; and the line with slope m sub P and passing through is called the tangent line to the curve e at P.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\nFormula for Slope: Suppose e is given by y = f(x), where f is a function; and P(x sub 0, f(x sub 0)) is a point on e. For any point Q on e with Q not equal to P, its x-coordinate can be written as x sub 0 + h where h is not equal to 0 (if h > 0, Q is on the right of P; if h < 0, Q is on the left of P). Thus, Q can be written as (x sub 0 + h, f(x sub 0 + h)). The slope m sub PQ of the secant line PQ is')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.075, 'left': 1.075}
            Image:
                source: "Doc/derivative4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nNote that as Q approaches P, the number h approaches 0. From these, we see that the slope of e at P(denoted by m sub P) is\n\n(4.1.1)\n\n\nprovided that the limit exists.\n\nThe limit in (4.1.1) is a two-sided limit. This is because Q can approach P from the left or from the right and so h can apporoach 0 from the left or from the right.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.88, 'left': 0.88}
            Image:
                source: "Doc/derivative5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenderivatives1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenderivatives3'

<ScreenDerivatives3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Example: Find the slope of the curve given by y = x^2 at the point P(3,9).\n\nSolution:\nPut f(x) = x^2. By (4.1.1), the required slope (denoted by m sub P) is')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.1, 'left': 1.1}
            Image:
                source: "Doc/derivative6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenderivatives2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenderivatives4'

<ScreenDerivatives4>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.25, 'left': 1.25}
            Image:
                source: "Doc/derivative7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenderivatives3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp3'

<ScreenDiffrules>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Rules for Differentiation[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n[b]Derivative of Constant[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\nThe derivative of a constant function is 0 (the zero function), that is\n\n\n\n\nwhere c is constant.\n\nIn the above formula, we use c to denote the constant function f given by f(x) = c. The domain of f is R (real number). The result means that f is differentiable on R and that f\'(x) = 0 for all x that elements are R.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.32, 'left': 1.32}
            Image:
                source: "Doc/diffrules.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.07, 'left': 1.07}
            Image:
                source: "Doc/diffrules1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.87, 'left': 0.87}
            Image:
                source: "Doc/diffrules2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nGeometric meaning: The graph of the constant function c is the horizontal line given by y = c. At every point on the line, the slope is 0.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp6'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules1'

<ScreenDiffrules1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Derivative of Identity Function[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\nThe derivative of the identity function is the constant function 1, that is')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.37, 'left': 1.37}
            Image:
                source: "Doc/diffrules3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\nExplanation: In the above formula, we use x to denote the identity function, that is, the function f given by f(x) = x. The domain of f is R. The result means that f is differentiable on R and f\'(x) = 1 for all x that elements are R.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.17, 'left': 1.17}
            Image:
                source: "Doc/diffrules4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.95, 'left': 0.95}
            Image:
                source: "Doc/diffrules5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nGeometric meaning: The graph of the identity function is the line given by y = x. At every point on the line, the slope is 1.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules2'

<ScreenDiffrules2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Power Rule for Differentiation (positive integer version)[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\nLet n be a positive integer. Then the power function x^n is differentiable on R and we have')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.37, 'left': 1.37}
            Image:
                source: "Doc/diffrules6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\nExplanation: In the above formula, we use x^n to denote the n-th power function, that is, the function f given by f(x) = x^n. The domain of f is R. The result means that f is differentiable on R and f\'(x) = nx^n-1 for all x that elements are R. When n = 1, the formula becomes  d/dx (x) = 1x^0. In the expression on the right side, x^0 is understood to be the constant function 1 and so the formula reduces to d/dx (x) = 1 which is the rule for derivative of the identity function. To prove that the result is true for all positive integers n, we can use mathematical induction. For base step, we know that the result is true when n = 1. For the induction step, we can apply product rule. Below we will give alternative proofs for the power rule (positive integer version).')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.96, 'left': 0.96}
            Image:
                source: "Doc/diffrules7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.865, 'left': 0.865}
            Image:
                source: "Doc/diffrules8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nTo find the limit we \'\'simplify\'\' the numerator to obtain a factor h and then cancel it with the factor h in the denominator. For this, we can use:\nA Factorization Formula')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.625, 'left': 0.625}
            Image:
                source: "Doc/diffrules9.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules3'

<ScreenDiffrules3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('The Binomial Theorem')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.445, 'left': 1.445}
            Image:
                source: "Doc/diffrules10.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.345, 'left': 1.345}
            Image:
                source: "Doc/diffrules11.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\nExplanation: The notation y = x^123 represents a power function. To find dy/dx means to find the derivative of the function.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.11, 'left': 1.11}
            Image:
                source: "Doc/diffrules12.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Constant Multiple rule for Differentiation[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nLet f be a function and let k be a constant. Suppose that f is differentiable. Then the function kf is also differentiable. Moreover, we have')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.8, 'left': 0.8}
            Image:
                source: "Doc/diffrules13.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExplanation: The function kf is defined by (kf)(x) = k * f(x) for x such that elements are domain (f). The result means that if f\'(x) exists for all x such that elements are domain (f), then (kf)\'(x) = k * f\'(x) for all x such that elements are domain (f), that is, (kf)\' = k * f\'.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules4'

<ScreenDiffrules4>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Proof by definition we have')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.28, 'left': 1.28}
            Image:
                source: "Doc/diffrules14.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.02, 'left': 1.02}
            Image:
                source: "Doc/diffrules15.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.85, 'left': 0.85}
            Image:
                source: "Doc/diffrules16.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules5'

<ScreenDiffrules5>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Sum Rule for Differentiation (Term by Term Differentiation)[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\nLet f and g be functions with the same domain. Suppose that f and g are differentiable. Then the function f + g is also differentiable. Moreover, we have')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\nExplanation: The function f + g is defined by (f + g)(x) = f(x) + g(x) for x belonging to the common domain A of f and g. The result means that if f\'(x) and g\'(x) exist for all x such that elements A, then (f + g)\'(x) = f\'(x) + g\'(x) for all x such that elements A, that is, (f + g)\' = f\' + g\'.\n\nProof by definition, we have')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.34, 'left': 1.34}
            Image:
                source: "Doc/diffrules17.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.9, 'left': 0.9}
            Image:
                source: "Doc/diffrules18.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules6'

<ScreenDiffrules6>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Example:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.43, 'left': 1.43}
            Image:
                source: "Doc/diffrules19.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.28, 'left': 1.28}
            Image:
                source: "Doc/diffrules20.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.09, 'left': 1.09}
            Image:
                source: "Doc/diffrules21.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.95, 'left': 0.95}
            Image:
                source: "Doc/diffrules22.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Quotient Rule[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nLet f and g be functions with the same domain. Suppose that f and g are differentiable and that g has no zero in its domain. Then the function f/g is also differentiable. Moreover, we have,')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules7'

<ScreenDiffrules7>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.42, 'left': 1.42}
            Image:
                source: "Doc/diffrules23.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\nExplanation: The condition \'\'g has no zero in its domain\'\' means that g(x) is not equal to 0 for all x such that elements are domain (g). The function f/g is defined by (f/g)(x) = f(x)/g(x) for x such that elements A, where A is the common domain of f and g. The result means that if f\'(x) and g\'(x) exist for all x such that elements A, then (f/g)\'(x) = g(x)f\'(x) - f(x)g\'(x)/g(x)^2 for all  x such that elements A, that is, (f/g)\' = gf\' - fg\'/g^2.\n\nProof: The proof is similar to that for the product rule.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.02, 'left': 1.02}
            Image:
                source: "Doc/diffrules24.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.77, 'left': 0.77}
            Image:
                source: "Doc/diffrules25.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules6'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules8'

<ScreenDiffrules8>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Product Rule[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\nLet f and g be functions with the same domain. Suppose that f and g are differentiable. Then the function fg is also differentiable. Moreover, we have')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.34, 'left': 1.34}
            Image:
                source: "Doc/diffrules26.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\nExplanation: The function fg is defined by (fg)(x) = f(x) * g(x) for x belonging to the common domain A of f and g. The result means that if f\'(x) and g\'(x) exist for all x such that elements A, then (fg)\'(x) = g(x)f\'(x) + f(x)g\'(x) for all x such that elements A, that is, (fg)\' = gf\' + fg\'.\n\nProof: By definition, we have')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.01, 'left': 1.01}
            Image:
                source: "Doc/diffrules27.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nTo find the limit, we use the following technique: \'\'subtract and add\'\' f(x + h)g(x) in the numerator.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.75, 'left': 0.75}
            Image:
                source: "Doc/diffrules28.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules7'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules9'

<ScreenDiffrules9>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.41, 'left': 1.41}
            Image:
                source: "Doc/diffrules29.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\nIn the last step, the first limit is found by substitution because f is continuous; the third limit is g(x) because considered as a function of h, g(x) is a constant.\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.16, 'left': 1.16}
            Image:
                source: "Doc/diffrules30.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.035, 'left': 1.035}
            Image:
                source: "Doc/diffrules31.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.855, 'left': 0.855}
            Image:
                source: "Doc/diffrules32.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]OTHERS: DERIVATIVE OF THE SQUARE ROOT FUNCTION[b]')
                halign: 'left'
                font_size: 20
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffrules8'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp6'

<ScreenChainrule>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Chain Rule[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nUp to this stage, we know how to differentiate \'\'simple\'\' functions like the following:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.26, 'left': 1.26}
            Image:
                source: "Doc/chainrule.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\nusing simple rules for differentiation and formulas derived in the last few chapters. But for more \'\'complicated\'\' functions, like the following:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.96, 'left': 0.96}
            Image:
                source: "Doc/chainrule1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nwe need the chain rule. It is one of the most important rules for finding derivatives, used for differentiating composite functions.\n\n\n\n\n\nExplanation: More precisely, we have the following result for differentiation of composition of functions.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.75, 'left': 0.75}
            Image:
                source: "Doc/chainrule2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp6'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenchainrule1'

<ScreenChainrule1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Let f be a function that is differentiable on an open interval (a,b). Let g be a function that is differentiable on an open interval containing the image of (a,b) under f. Moreover, we have')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.38, 'left': 1.38}
            Image:
                source: "Doc/chainrule3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\nIf we denote u = f(x) and denote y = g(u), then y = g(f(x)) is a function of x. Note that (g o f)\' = dy/dx, g\' = dy/du and f\' = du/dx. The Chain Rule is a compact way to express the relation between the derivatives of g o f, g and f. Below we show how to derive the rule (with an additional assumption):')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.995, 'left': 0.995}
            Image:
                source: "Doc/chainrule4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample:\n\n\n\n(1)without using chain rule\n(2)using chain rule')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.72, 'left': 0.72}
            Image:
                source: "Doc/chainrule5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenchainrule'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenchainrule2'

<ScreenChainrule2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Solution:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.42, 'left': 1.42}
            Image:
                source: "Doc/chainrule6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.25, 'left': 1.25}
            Image:
                source: "Doc/chainrule7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nWe can combine the chain rule with any formula to get a more general formula. In the table that can be found at the next page, the general form gives the derivative of g o f where g is a power function, the sine function etc. and f is  adifferentiable function such that g o f is defined (for example, in order that ln[f(x)] be defined, we have to assume that f is positive). These formulas will be referred as the Chain Rule and Power Rule, Chain Rule and Derivative of sin etc. For the Power Rule, we have seen that it is true if r is an integer or a rational number in the form n + 1/2 where n is an integer. In fact, it is true for all real numbers r.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenchainrule1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenchainrule3'

<ScreenChainrule3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.26, 'left': 1.26}
            Image:
                source: "Doc/chainrule8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample:\nFor each of the following y, find dy/dx.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.77, 'left': 0.77}
            Image:
                source: "Doc/chainrule9.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenchainrule2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenchainrule4'

<ScreenChainrule4>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Solution:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.4, 'left': 1.4}
            Image:
                source: "Doc/chainrule10.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.27, 'left': 1.27}
            Image:
                source: "Doc/chainrule11.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.125, 'left': 1.125}
            Image:
                source: "Doc/chainrule12.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.965, 'left': 0.965}
            Image:
                source: "Doc/chainrule13.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.825, 'left': 0.825}
            Image:
                source: "Doc/chainrule14.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': .72, 'left': 0.72}
            Image:
                source: "Doc/chainrule15.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenchainrule3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenchainrule5'

<ScreenChainrule5>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.28, 'left': 1.28}
            Image:
                source: "Doc/chainrule16.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.967, 'left': 0.967}
            Image:
                source: "Doc/chainrule17.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.767, 'left': 0.767}
            Image:
                source: "Doc/chainrule18.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenchainrule4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp6'

<ScreenAngles>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Angles[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n[b]Idea of Definition:[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n                                  An angle is formed by rotating a ray about its endpoint.\n\nThe initial position of the ray is called the initial side.\nThe endpoint of the ray is called the vertex.\nThe final position is called the terminal side.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\nAn angle is said to be in standard position if its vertex is at the origin and its initial side is along the positive x-axis.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\nNote: An angle in standard position is uniquely determined by the direction and magnitude of rotation. So we can use numbers to represents angles.\n\nThe direction of rotation may be counterclockwise or clockwise which will be considered to be positive or negative respectively.\n\nMagnitudes of rotation are traditionally measured in degrees where one revolution is defined to be 360 degrees.\n\nFigures 7.1(a), (b) and (c) show three angles in standard position: Although the angles have the same terminal sides, their measures are different.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nAnother unit for measuring angles is the radian. to define radian, we consider unit circles.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True
                
        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.75, 'left': 0.75}
            Image:
                source: "Doc/angles.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp6'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenangles1'

<ScreenAngles1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Terminology: A circle with radius 1 is called a unit circle. The cirle with radius 1 and center at the origin is called the unit circle.\nDefinition: The angle determined by an arc of length 1 along the circumference of a unit circle is said to be of measure one radian.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.285, 'left': 1.285}
            Image:
                source: "Doc/angles1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\nSince the circumference of a unit circle has length 2pi, there are 2pi radians in one revolution. Therefore, we have 360 degrees = 2pi radians. The conversion between degrees and radians is given by')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThus, we have 90 degrees = pi/2 (radian) and 60 degrees = pi/3 (radian) for example.\n\nRemark: In calculus, it is more convenient to consider angles in radians and the unit radian is usually omitted.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.03, 'left': 1.03}
            Image:
                source: "Doc/angles2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Trigonometric Functions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nNotation: Consider an angle (in theta) in standard position. Let P be the point of intersection of the terminal side and the unit circle. We define')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenangles'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenangles2'

<ScreenAngles2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('sin theta = y-coordinate of P     (7.2.1)\ncos theta = x-coordinate of P     (7.2.2)')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\nRemark: Instead of considering the unit circle, we can also use circle of radius r (centered at the origin) and define cos theta = a/r and sin theta = b/r, where a and b are the x- and y-coordinates of P respectively. It is easily seen (using similar triangles) that these ratios are independent of the choices of r.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.15, 'left': 1.15}
            Image:
                source: "Doc/angles3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nDefinition: The rules given (7.2.1) and (7.2.2) define two functions from R into R, called the sine and cosine functions respectively.\n\nUsing the sine and cosine functions, we define four more trigonometric functions, called the tangent (denoted by tan), cotangent (denoted by cot), secant (denoted by sec) and cosecant (denoted by csc) functions as follows:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenangles1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenangles3'

<ScreenAngles3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.35, 'left': 1.35}
            Image:
                source: "Doc/angles4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\nNote sin x = 0 if and only if x = k * pi for some integer k and cos x = 0 if and only if x = k * pi/2 for some odd integer k, it follows that')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.08, 'left': 1.08}
            Image:
                source: "Doc/angles5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nBelow we will discuss some results for the sine, cosine and tangent functions. The secant function will only be used in an identity and a formula for differentiating the tangent function. The cotangent nd cosecant functions will not be used in this course.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nProperties\n(1) The sine and cosine functions are periodic with period 2pi, that is,')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.71, 'left': 0.71}
            Image:
                source: "Doc/angles6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenangles2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenangles4'

<ScreenAngles4>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('(2) The tangent function is periodic with period pi, that is,')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.44, 'left': 1.44}
            Image:
                source: "Doc/angles7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n(3) The sine function and the tangent function are odd functions and the cosine functions is an even function, that is')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.3, 'left': 1.3}
            Image:
                source: "Doc/angles8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n(4) From (3), we see that the graphs of the sine function and tangent function are symmetric about the origin and the graph of the cosine function is symmetric about the y-axis. See Figures 7.4(a),(b) and (c).')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.98, 'left': 0.98}
            Image:
                source: "Doc/angles9.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.77, 'left': 0.77}
            Image:
                source: "Doc/angles10.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenangles3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenangles5'

<ScreenAngles5>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.315, 'left': 1.315}
            Image:
                source: "Doc/angles11.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]CAST RULE[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe signs of sine, cosine and tangent in each quadrant can be memorized using the folllowing rule:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nwhere C stands for cosine, A for all, S for sine and T for tangent - for example, C in the 4th quadrant means that if x is an angle in the fourth quadrant, then cos x is positive and the other two values sin x and tan x are negative.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.96, 'left': 0.96}
            Image:
                source: "Doc/angles12.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenangles4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenangles6'

<ScreenAngles6>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.33, 'left': 1.33}
            Image:
                source: "Doc/angles13.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\nThe values of the sine, cosine and tangent functions at the special angles can be obtained by drawing appropriate figures or triangles. For example, we can use Figures 7.5(a), (b) and (c) to find the values of the trigonometric functions for angles with size pi/2, pi/4 and pi/6 respectively.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.86, 'left': 0.86}
            Image:
                source: "Doc/angles14.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]THE NEXT PAGE SHOWS MORE IDENTITIES.[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenangles5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenangles7'

<ScreenAngles7>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.26, 'left': 1.26}
            Image:
                source: "Doc/angles15.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]COMPOUND ANGLE FORMULAS[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nLet A and B be real numbers. Then we have')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nRemark: The formulas for sin(A-B) and cos(A-B) can be deduced from that for sin(A+B) and cos(A+B) respectively. This is because sin(-x) = -sinx and cos(-x) = cos x for all x such that elements are real numbers. Moreover, since sin(pi/2 - x) = cos x and cos (pi/2) = sin x, the formula for sin (A+B) can be deduced from that for cos(A+B) and vice versa. However, the proof for either formula is very tedious and thus is omitted.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.85, 'left': 0.85}
            Image:
                source: "Doc/angles16.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenangles6'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp6'

<ScreenDifftrigo>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Derivative of sin[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\nThe sine function is differentiable on R and its derivative is the cosine function, that is,')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.2, 'left': 1.2}
            Image:
                source: "Doc/difftrigo.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\nThe sine function is differentiable on R and its derivative is the cosine function, that is,')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Derivative of cos[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe cosine function is differentiable on R and its derivative is the negative of the sine function, that is,')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.85, 'left': 0.85}
            Image:
                source: "Doc/difftrigo1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nProof: Similar to that for the derivative of the sine function, the result can be proved by definition, using the compound angle formula cos(x + h) = cosxcosh - sinxsinh.\n\nRemark: Note that cos x = sin (pi/2 - x). The result can also be proved using the result for the derivative of the sine function together with the chain rule.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp6'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screendifftrigo1'

<ScreenDifftrigo1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Derivative of tan[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\nThe tangent function is differentiable on its domain and its derivative is the square of the secant function, that is,\n\n\n\n\nProof:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.37, 'left': 1.37}
            Image:
                source: "Doc/difftrigo2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.1, 'left': 1.1}
            Image:
                source: "Doc/difftrigo3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample: For each of the following y, find dy/dx.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.71, 'left': 0.71}
            Image:
                source: "Doc/difftrigo4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screendifftrigo'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screendifftrigo2'

<ScreenDifftrigo2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Solution:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.38, 'left': 1.38}
            Image:
                source: "Doc/difftrigo5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.2, 'left': 1.2}
            Image:
                source: "Doc/difftrigo6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1, 'left': 1}
            Image:
                source: "Doc/difftrigo7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.78, 'left': 0.78}
            Image:
                source: "Doc/difftrigo8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screendifftrigo1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp6'

<ScreenGradient>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]The gradient of secants and tangents to a graph[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\nConsider a function f: R is to R and its graph y = f(x), which is a curve in the plane. We wish to find the gradient of this curve at a point. But first we need to define properly what we mean by the gradient of a curve at a point!\n\nThe module Coordinate geometry defines the gradient of a line in the plane. Given a non-vertical line and two points on it, the gradient is defined as rise/run.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.05, 'left': 1.05}
            Image:
                source: "Doc/gradient.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nNow, given a curve defined by y = f(x), and a point p on the curve, consider another point q on the curve near p, and draw the line pq connecting p and q. This line is called a secant line.\n\nWe write the coordinates of p as (x,y), and the coordinates of q as (x + small change of x, y + small change of y).\nNOTE: The triangle symbol stands as the small change.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screengradient1'

<ScreenGradient1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.34, 'left': 1.34}
            Image:
                source: "Doc/gradient1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\nAs the small change in x (denoted by triangle symbol) becomes smaller and smaller, the point q approaches p, and the secant line pq approaches a line called the tangent to the curve at p. We define the gradient of the curve at p to be the gradient of this tangent line.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.89, 'left': 0.89}
            Image:
                source: "Doc/gradient2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nNote that, in this definition, the approximation of a tangent line by secant lines is just like the approximation of instantaneous velocity by average velocities. With this definition, we now consider how to compute the gradient of the curve y = f(x) at the point p = (x,y).')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screengradient'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screengradient2'

<ScreenGradient2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.32, 'left': 1.32}
            Image:
                source: "Doc/gradient3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe notation dy/dx indicates the instantaneous rate of change of y with respect to x, and is not a fraction. For our purposes, the expressions dx and dy have no meaning on their own, and the d\'s do not cancel!\n\nThe gradient of a secant is analogous to average velocity, and the gradient of a tangent is analogous to instantaneous velocity. Velocity is the instantaneous rate of change of position with respect to time, and the gradient of a tangent to the graph y = f(x) is the instantaneous rate of change of y with respect to x.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screengradient1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp4'

<ScreenCgradient>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Calculating the gradient of y = x^2[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\nLet us consider a specific function f(x) = x^2 and its graph y = f(x), which is the standard parabola. To illustrate the ideas in the previous section, we will calculate the gradient of this curve at x = 1.\n\nWe first construct secant lines between the points on the graph at x = 1 and x = 1 + small change at x, and calculate their gradients.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.06, 'left': 1.06}
            Image:
                source: "Doc/cgradient.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nFor instance, a change in x (dnoted by triangle symbol) = 2, we consider the secant connecting the points at x = 1 and x = 3. Between these two points, f(x) increases from f(1) = 1 to f(3) = 9, giving a change of y = 8, and hence')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nWe compute gradients of secants for various values of change of x in the following table at he next page.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.733, 'left': 0.733}
            Image:
                source: "Doc/cgradient1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screencgradient1'

<ScreenCgradient1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.35, 'left': 1.35}
            Image:
                source: "Doc/cgradient2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\nAs change in x approaches 0, the gradients of the secants approach 2. It turns out that indeed the gradient of the tangent at x = 1 is 2. To see why, consider the interval of length change in x, from x = 1 to x = 1 + change in x. We have')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.94, 'left': 0.94}
            Image:
                source: "Doc/cgradient3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.70, 'left': 0.70}
            Image:
                source: "Doc/cgradient4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screencgradient'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screencgradient2'

<ScreenCgradient2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('(So, if you were riding your bike and your position was f(x) = x^2 metres after x seconds, then your instantaneous velocity after 1 second would be 2 metres per second.)')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\nThere\'s nothing special about the point x = 1 or the function f(x) = x^2, as the following example illustrates.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.12, 'left': 1.12}
            Image:
                source: "Doc/cgradient5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screencgradient1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp4'

<ScreenDefderivative>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Definition of the derivative[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nThe method we used in the previous section to find the gradient of a tangent to a graph at a point can actually be used to work out the gradient everywhere, simultaneously.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.3, 'left': 1.3}
            Image:
                source: "Doc/defderivative.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.1, 'left': 1.1}
            Image:
                source: "Doc/defderivative1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe derivative of a function f(x) is the function f\'(x) which gives the gradient of the tangent to the graph y = f(x) at each value of x. It is often also denoted dy/dx. Thus')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.8, 'left': 0.8}
            Image:
                source: "Doc/defderivative2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe previous example shows that the derivative of f(x) = x^2 is f\'(x) = 2x')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screendefderivative1'

<ScreenDefderivative1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Functions which have derivatives are called differentiable. Not all functions are differentiable; in particular, to be differentiable, a function must be continuous. Almost all functions we meet secondary school mathematics are differentiable. In particular, all polynomials, rational functions, exponentials, logarithms and trigonometric functions (such as sin, cos and tan) are differentiable.\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.063, 'left': 1.063}
            Image:
                source: "Doc/defderivative3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screendefderivative'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp4'

<ScreenNotation>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Notation for the derivative[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\nWe have introduced two different notation for the derivative. Both are standard, and it is necessary to be proficient with both.\n\nThe first notation is to write f\'(x) for the derivative of the function f(x). This functional notation was introduced by Langrange, based on Isaac Newton\'s ideas. The dash in f\'(x) denotes that f\'(x) is derived from f(x).\n\nThe other notation is to write dy/dx. This notation refers to the instantaneous rate of change of y with respect to x, and was introduced by Gottfried Wilhelm Leibniz, one of the discoverers of calculus. (The other discoverer was Isaac Newton. In fact, the question of who discovered calculus first was historically a point of great controversy.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nIf we have a function f(x) and its graph y = f(x), then the derivative f\'(x) is the gradient of the tangent of y = f(x), which is also the instantaneous rate of change dy/dx. Thus the notations are equivalent:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.85, 'left': 0.85}
            Image:
                source: "Doc/notation.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nFor example, we calculated earlier that the derivative of x^2 was 2x. Thus y = x^2 implies  dy/dx = 2x. Alternatively, f(x) = x^2 implies f\'(x) = 2x. The two notations express the same result.\n\nAnother common sense usage of Leibniz notation is to consider d/dx as an operator, meaning \'differentiate with respect to x\'.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screennotation1'

<ScreenNotation1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('So,')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.422, 'left': 1.422}
            Image:
                source: "Doc/notation1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\nmeans: take y, and differentiate with respect to x. An alternative way to denote differentiation of x^2 using Leibniz notation would be')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.24, 'left': 1.24}
            Image:
                source: "Doc/notation2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\nAt secondary school level, a \'d\' or \'dx\' or \'dy\' has no meaning in itself; it only makes sense as part of a d/dx or dy/dx or similar. The d\'s do not cancel.\n\nThe two types of notation each have their advantages and disadvantages. It is also common tomix notation. For example, we can write')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.97, 'left': 0.97}
            Image:
                source: "Doc/notation3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screennotation'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp4'

<ScreenProperties>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Properties of the derivative[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nWe now consider various properties of differentiation. As we proceed, we will be able to differentiate wider and wider classes of functions. Throughout this section, we will be manipulating limits as we compute derivatives. We therefore recall some basic rules for limits. See the part of the basic calculus for the limits and continuity for details. The following hold provided the limits limit of f(x) as x approaches a  and limit of g(x) exist as x approaches a.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\nThe limit of a sum (or difference) is the sum (or difference) of the limits:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.122, 'left': 1.122}
            Image:
                source: "Doc/properties.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe limit of a product is the product of the limits:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.032, 'left': 1.032}
            Image:
                source: "Doc/properties1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThis includes the case of multiplication by a constant c:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.95, 'left': 0.95}
            Image:
                source: "Doc/properties2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]The derivative of a constant multiple[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nSuppose we want to differentiate 4x^7. Rather than returning to the definition of a derivative, we can use the following theorem.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Theorem[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nLet f be a differentiable function and let c be a constant. Then the derivative of cf(x) is cf\'(x). That is')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenproperties1'

<ScreenProperties1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.44, 'left': 1.44}
            Image:
                source: "Doc/properties3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\nThis fact can also be written in Leibniz notation as')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.322, 'left': 1.322}
            Image:
                source: "Doc/properties4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n[b]Proof[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\nThe derivative of cf(x) is given by\n\n\n\nWe may factor out the c, since it is just a constant.\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.16, 'left': 1.16}
            Image:
                source: "Doc/properties5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.9, 'left': 0.9}
            Image:
                source: "Doc/properties6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]The derivative of a sum[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nA function like f(x) = x^3 + 5x^2 can be differentiated from first principles; alternatively, we can use the following theorem.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenproperties'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenproperties2'

<ScreenProperties2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Theorem[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\nSuppose both f and g are differentiable functions. Then the derivative of f(x) + g(x) is f\'(x) + g\'(x) and, similarly, the derivative of f(x) - g(x) is f\'(x) - g\'(x). That is,')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.353, 'left': 1.353}
            Image:
                source: "Doc/properties7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\nIn Leibniz notation, these statements can be written as')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.23, 'left': 1.23}
            Image:
                source: "Doc/properties8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n[b]Theorem[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\nWe prove the first statement. The derivative of f(x) + g(x) is given by')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.98, 'left': 0.98}
            Image:
                source: "Doc/properties9.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nNote that, as both the limits in the second line exist, we are retrospectively justified in splitting the first limit into two pieces.\n\nExample:\nFind the derivative of f(x) = x^3 + 5x^2.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenproperties1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenproperties3'

<ScreenProperties3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.32, 'left': 1.32}
            Image:
                source: "Doc/properties10.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\nNote. The solution to the previous example shows every individual step explicitly and states which theorems are used. Once proficient with these  properties of the derivative, however, there is no need to justify each step in this way. It is common, for instance, to go straight from')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nf(x) = x^3 + 5x^2   to   f\'(x) = 3x^2 + 10x')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenproperties2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp4'

<ScreenSummary>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Summary of differentiation rules[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nWe can summarise the differentiation rules we have found as follows. They can be expressed in both functional and Leibniz notation. First, the linearity of differentiation.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.21, 'left': 1.21}
            Image:
                source: "Doc/summary.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nWe also have the product, quotient and chain rules. In Leibniz notation, these rules are often write with u, v rather than f, g.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.82, 'left': 0.82}
            Image:
                source: "Doc/summary1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp4'

<ScreenTangent>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]The tangent line to a graph[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nGiven a graph y = f(x), we have seen how to calculate the gradient of a tangent line to this graph. We can go further and find the equation of a tangent line.\n\nConsider the tangent line to the graph y = f(x) at x = a. This line has gradient f\'(a) and passes through the point (a, f(a)). Once we know a point on the line  and its gradient, we can write down its equation:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\ny - f(a) = f\'(a)(x - a).')
                halign: 'center'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1, 'left': 1}
            Image:
                source: "Doc/tangent.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp7'

<ScreenSecderivative>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]The Second Derivative[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nGiven a function f(x), we can differentiate it to obtain f\'(x). It can be useful for many purposes to differentiate again and consider the second derivative of a function.\n\nIn functional notation, the second derivative is denoted by f\'\'(x). in Leibniz notation, letting y = f(x), the second derivatives is denoted by d^2y/dx^2.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\nThe placement of the 2\'s in the notation d^2y/dx^2 may appear unusual. We consider that we have applied the differentiation operator d/dx twice to y:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.04, 'left': 1.04}
            Image:
                source: "Doc/secderivative.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe second derivative can be very useful in curve-sketching. The second derivative determines the convexity of the graph y = f(x) and can, for example, be used to distinguish maxima from minima.\n\nThe second derivative can also have a physical meaning. For example, if x(t) gives position at time t, then x\'(t) is the velocity and the second derivative x\'\'(t) is the acceleration at time t.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp7'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screensecderivative1'

<ScreenSecderivative1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Example:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.38, 'left': 1.38}
            Image:
                source: "Doc/secderivative1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.05, 'left': 1.05}
            Image:
                source: "Doc/secderivative2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screensecderivative'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp7'

<ScreenInverse>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Differentiation of Inverses[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nA clever use of the chain rule arises when we have a function f and its inverse function f^-1.\n\nLetting y = f(x), we can express x as the inverse function of y:\n\n                                                y = f(x),      x = f^-1(y).')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\nThe composition of f and its inverse f^-1, by definition, is just x. That is, f^-1 (f(x)) = x. Wecan think of this diagrammatically as')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.15, 'left': 1.15}
            Image:
                source: "Doc/inverse.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\nUsing the chain rule, we can differentiate this composition of functions to obtain')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.02, 'left': 1.02}
            Image:
                source: "Doc/inverse1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe derivative dx/dx of x with respect to x is just 1, so we obtain the important formula')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.87, 'left': 0.87}
            Image:
                source: "Doc/inverse2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nwhich can also be expressed as')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.73, 'left': 0.73}
            Image:
                source: "Doc/inverse3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThis formula allows us to differentiate inverse functions, as in the following example.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp7'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screeninverse1'

<ScreenInverse1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.3, 'left': 1.3}
            Image:
                source: "Doc/inverse4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screeninverse'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp7'

<ScreenImplicit>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Implicit Differentiation[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nImplicit differentiation is a powerful technique to find an instantaneous rate of change dy/dx when there is an equation relating x and y. It applies even when y is not a function of x. All that is required is that there is an equation relating x and y. For example, consider the curve in the plane described by the equation x^2 + y^2 = 9. This is a circle centred at the origin, of radius 3.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.07, 'left': 1.07}
            Image:
                source: "Doc/implicit.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nNote that y is not a function of x! The circle fails the vertical-line test; we have a relation, not a function. For a given value of x, there may be two distinct values of y:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.753, 'left': 0.753}
            Image:
                source: "Doc/implicit1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nAlthough y is not a function of x, we can say that the equation x^2 + y^2 = 9 expresses y as an implicit function of x.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp7'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenimplicit1'

<ScreenImplicit1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Suppose you want to find the gradient of the tangent to this circle at a point (x,y). One approach would be to consider either f sub 1(x) = square root of 9-x^2 or f sub 2(x) = negative square root of 9-x^2, depending on whether y is positive or negative, and then differentiate.\n\nThe much better approach of implicit differentiation is to differentiate both sides of the equation x^2 + y^2 = 9 with respect to x. Differentiating y^2 requires the chain rule, since y^2 is a function of y and y is a function of x:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.18, 'left': 1.18}
            Image:
                source: "Doc/implicit2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\nWe can now differentiate each term of x^2 + y^2 = 9, and we obtain')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.02, 'left': 1.02}
            Image:
                source: "Doc/implicit3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nNote the power of implicit differentiation: this equation involving dy/dx is valid for all points on the circle except y = 0. When y is not equal to 0, we may solve for dy/dx and obtain')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.85, 'left': 0.85}
            Image:
                source: "Doc/implicit4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nWithout implicit differentiation, we would not have found such a neat formula!\n\nFrom this formula we can see that if x,y have the same sign, then the gradient of the tangent is negative; while if x,y are of opposite sign, then the gradient is positive.\n\nExample at the next page.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenimplicit'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenimplicit2'

<ScreenImplicit2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.3, 'left': 1.3}
            Image:
                source: "Doc/implicit5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe curve in the previous example is called an elliptic curve.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenimplicit1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp7'

<ScreenProchain>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]The product, quotient and chain rules[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\nWe now move to some more involved properties of differentiation. To summarize, so far we have found that:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\nThe derivative of a constant multiple is the constant multiple of the derivative\n\nThe derivative of a sum is the sum of the derivatives')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\nThe derivative of a difference is the difference of the derivatives')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\nHowever, it turns out that:\n\nThe derivative of a product f(x)g(x) is not the product of the derivatives')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe derivative of a quotient f(x)/g(x) is not the quotient of the derivatives')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe derivative of the composition f(g(x)) is not the composition of the derivatives.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe product, quotient and chain rules tell us how to differentiate in these three situations. We consider the three rules in turn.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenprochain1'

<ScreenProchain1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]The product rule[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n[b]Theorem (Product Rule)[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\nLet f,g differentiable functions. Then the derivative of their product is given by')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.283, 'left': 1.283}
            Image:
                source: "Doc/prochain.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\nThe product rule is also often written as')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.15, 'left': 1.15}
            Image:
                source: "Doc/prochain1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Proof[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nAs before, we evaluate the limit which gives the derivative:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1, 'left': 1}
            Image:
                source: "Doc/prochain2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe trick is to add and subtract an extra term in the numerator, so that we can factorise and obtain some familiar-looking expressions:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.77, 'left': 0.77}
            Image:
                source: "Doc/prochain3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenprochain'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenprochain2'

<ScreenProchain2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('We can then rewrite the limit as')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.42, 'left': 1.42}
            Image:
                source: "Doc/prochain4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\nNow, since the limit of a sum is the sum of the limits, and the limit of a product is the product of the limits, we obtain')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.25, 'left': 1.25}
            Image:
                source: "Doc/prochain5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\nWe also used the fact that f(x) does not depend on the rate of change of x. Recognising f\'(x) and g\'(x), and substituting the change in x  (denoted by triangle symbol) = 0 into g(x + the change in x), we obtain')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.05, 'left': 1.05}
            Image:
                source: "Doc/prochain6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nwhich is equivalent to the desired formula.\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.773, 'left': 0.773}
            Image:
                source: "Doc/prochain7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenprochain1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenprochain3'

<ScreenProchain3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]The Chain Rule[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nThe chain rule allows us to differentiate the composition of two functions. Recall from the module Functions II that the composition of two functions g and f is')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.32, 'left': 1.32}
            Image:
                source: "Doc/prochain8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\nWe start with x, apply g, then apply f. The chain rule tells us how to differentiate such a function.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n[b]Theorem (Chain Rule)[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\nLet f,g be differentiable functions. Then the derivative of their composition is')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.085, 'left': 1.085}
            Image:
                source: "Doc/prochain9.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nIn Leibniz notation, we may write u = g(x) and y = f(u) = f(g(x)); diagrammatically,')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.935, 'left': 0.935}
            Image:
                source: "Doc/prochain10.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThen the chain rule says that \'differentials cancel\' in the sense that')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.8, 'left': 0.8}
            Image:
                source: "Doc/prochain11.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Proof[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nTo calculate the derivative, we must evaluate the limit')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.63, 'left': 0.63}
            Image:
                source: "Doc/prochain12.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenprochain2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenprochain4'

<ScreenProchain4>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('The trick is to multiply and divide by an extra term in the expression above, as shown, so that we obtain two expressions which both expresses rates of change:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.36, 'left': 1.36}
            Image:
                source: "Doc/prochain13.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\nWe can rewrite the desired limit as')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.233, 'left': 1.233}
            Image:
                source: "Doc/prochain14.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\nThe ratio in the first limit expresses the change in the function f, from its value at g(x) to its value at g(x + rate of change in x (denoted by triangle symbol)), relative to the difference between g(x + rate of change in x (denoted by triangle symbol)) and g(x). So as reate of change approaches to 0, this first term approaches the derivative of f at the point g(x), namely f\'(g(x)). The second limit is clearly g\'(x). We conclude that')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.945, 'left': 0.945}
            Image:
                source: "Doc/prochain15.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nas required.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe proof above is not  entirely rigorous: for instance, if there are values of rate of change in x close to zero such that g(x + rate of change in x) - g(x) = 0, then we have division by zero in the first limit. However, a fully rigorous proof is beyond the secondary school level.\n\nThe next two examples illustrate \'functional\' and \'Leibniz\' methods of attacking the same problem using the chain rule.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenprochain3'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenprochain5'

<ScreenProchain5>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Examples:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.3, 'left': 1.3}
            Image:
                source: "Doc/prochain16.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.88, 'left': 0.88}
            Image:
                source: "Doc/prochain17.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenprochain4'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenprochain6'

<ScreenProchain6>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]The Quotient Rule[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n[b]Theorem[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\nLet f,g be differentiable functions. Then the derivative of their quotient is')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.31, 'left': 1.31}
            Image:
                source: "Doc/prochain18.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\nAlternatively, we can write\n\n\n\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.17, 'left': 1.17}
            Image:
                source: "Doc/prochain19.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.92, 'left': 0.92}
            Image:
                source: "Doc/prochain20.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenprochain5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenprochain7'

<ScreenProchain7>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('Another example:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.1, 'left': 1.1}
            Image:
                source: "Doc/prochain21.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe quotient rule can be proved using product and chain rules.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenprochain6'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp4'

<ScreenAbout>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]About the Application[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nThis application is about the branch of calculus including:\n\nPRE-CALCULUS\nBASIC-CALCULUS\nDIFFERENTIAL CALCULUS\nINTEGRAL CALCULUS\n\nIt also contains different exercises after all the lessons.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\nThe following information in this application came from different sources and pdf\'s. The references will be included in this section.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\nREFERENCES:\n\nChung, S. K. (2014). Understanding Basic Calculus. Graduate School of Mathematics, Nagoya University\n\nMathews, D. (2013). Introduction to differential calculus - A guide for teachers (Years 11-12). Australia: Education Services Australia\n\nFischer, I. Basic Calculus Refresher. UW-Madison Statistics\n\nStewart, J., Redlin, L., & Watson, S. (2012). Precalculus: mathematics for calculus. (6th ed.). USA: United States of America\n\nYue, X. L. (2004). Lecture Notes on Integral Calculus. UBC Math 103 Lecture Notes')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenmain'

<ScreenFundaterms>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]The Fundamental Theorem in Terms of Differentials[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n[b]Fundamental Theorem of Calculus[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\nIf F(x) is one antiderivative of the function f(x), i.e., F\'(x) = f(x), then')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.263, 'left': 1.263}
            Image:
                source: "Doc/fundaterms.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\nThus, the integral of the differential of a function F is equal to the function itself plus an arbitrary constant. This is simply saying that differential and integral are inverse math operations of each other. If we first differentiate a function F(x) and then integrate the derivative F\'(x) = f(x), we obtain F(x) itself plus an arbitrary constant. The opposite also is true. If we first integrate a function f(x) and then differentiate the resulting integral F(x) + C, we obtain F\'(x) = f(x) itself.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nExample/s:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.87, 'left': 0.87}
            Image:
                source: "Doc/fundaterms1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.77, 'left': 0.77}
            Image:
                source: "Doc/fundaterms2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.67, 'left': 0.67}
            Image:
                source: "Doc/fundaterms3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenfundaterms1'

<ScreenFundaterms1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.35, 'left': 1.35}
            Image:
                source: "Doc/fundaterms4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.25, 'left': 1.25}
            Image:
                source: "Doc/fundaterms5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.15, 'left': 1.15}
            Image:
                source: "Doc/fundaterms6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenfundaterms'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp5'

<ScreenSubstitution>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Integration by Substitution[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\nSubstitution is a necessity when integrating a composite function since we cannot write down the antiderivative of a composite function in a straightforward manner.\n\nMany students find it difficult to figure out the substitution since for different functions the substitutions are also different. However, there is a general rule in substitution, namely, to change the composite function into a simple, elementary function.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.17, 'left': 1.17}
            Image:
                source: "Doc/substitution.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\nSolution: Note that sin(square root of x) is not an elementary sine function but a composite function. The first goal in solving this integral is to change sin (square root of x) into an elementary sine function through substitution. Once you realize this, u = square root of x is an obvious substitution. Thus, du = u\'dx = 1/2(square root of x)dx, or dx = 2 (square root of x)du = 2udu. Substitute into the integral, we obtain')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.92, 'left': 0.92}
            Image:
                source: "Doc/substitution1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nOnce you become more experienced with substitutions and differentials, you do not need to do the ctual substitution but only symbolically. Note that x = (square root of x)^2,')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.755, 'left': 0.755}
            Image:
                source: "Doc/substitution2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThus, as soon as you realize that square root of x is the substitution, your goal is to change the differential in the integral dx into the differential of square root of x which is d square root of x.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screensubstitution1'

<ScreenSubstitution1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.445, 'left': 1.445}
            Image:
                source: "Doc/substitution3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\nSolution: Note that cos (x^5) is a composite function that becomes a simple cosine function only if the substitution u = x^5 is made. Since du = u\'dx = 5x^4dx, x^4dx = 1/5du. Thus\n\n\n\n\nOr alternatively,')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.27, 'left': 1.27}
            Image:
                source: "Doc/substitution4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.15, 'left': 1.15}
            Image:
                source: "Doc/substitution5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screensubstitution'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp5'

<ScreenIntegparts>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Integration by Parts[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nIntegration by Parts is the integral version of the Product Rule in differentiation. The Product Rule in terms of differentials reads,\n\n\n\nIntegrating both sides, we obtain')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.353, 'left': 1.353}
            Image:
                source: "Doc/integparts.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.24, 'left': 1.24}
            Image:
                source: "Doc/integparts1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\nNote that the inegral of d (uv) = uv + C, the above equation can be expressed in the following form,')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.1, 'left': 1.1}
            Image:
                source: "Doc/integparts2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nGenerally speaking, we need to use Integration by Parts to solve many integrals that involve the product between two functions. In many cases, Integration by Parts is most efficient in solving integrals of the product between to a polynomial and an exponential, a logarithmic, or a trigonometric function. It also applies to the product between exponential and trigonometric functions.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.85, 'left': 0.85}
            Image:
                source: "Doc/integparts3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nSolution: In order to eliminate the power function x, we note that (x)\' = 1. Thus,')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.705, 'left': 0.705}
            Image:
                source: "Doc/integparts4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenintegparts1'

<ScreenIntegparts1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.475, 'left': 1.475}
            Image:
                source: "Doc/integparts5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\nSolution: In order to eliminate the power function x^2, we note that (x^2)\'\' = 2. Thus, we need to use Integration by Parts twice.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.32, 'left': 1.32}
            Image:
                source: "Doc/integparts6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.22, 'left': 1.22}
            Image:
                source: "Doc/integparts7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\nSolution: In order to eliminate the power function x^2, we note that (x^2)\'\' = 2. Thus, we need to use Integration by Parts twice. However, the number (-2) can prove extremely annoying and easily cause errors. Here is how we use substitution to avoid this problem.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.97, 'left': 0.97}
            Image:
                source: "Doc/integparts8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenintegparts'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp5'

<ScreenIntegfrac>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Integration by Partial Fractions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nRational functions are defined as the quotient between two polynomials: ')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.35, 'left': 1.35}
            Image:
                source: "Doc/integfrac.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\nwhere P sub n(x) and Q sub m(x) are polynomials of degree n and m respectively. The method of partial fractions is an algebraic technique that decomposes R(x) into a sum of terms:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.18, 'left': 1.18}
            Image:
                source: "Doc/integfrac1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\nwhere p(x) is a polynomial and F sub i(x), (i = 1,2,..., k) are fractions that can be integrated easily. ')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe method of partial fractions is an area many students find very difficult to learn. It is related to algebraic techniques that many students have not been trained to use. The most typical claim is that there is no fixed formula to use.\n\nCase 1:\n\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.85, 'left': 0.85}
            Image:
                source: "Doc/integfrac2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.74, 'left': 0.74}
            Image:
                source: "Doc/integfrac3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThis integral involves the simplest partial fractions:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenintegfrac1'

<Screenintegfrac1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.43, 'left': 1.43}
            Image:
                source: "Doc/integfrac4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\nSome may feel that it is easier to write the fractions in the following form: D^-1 (A + B + C) = D^-1 A + D^-1 B + D^-1 C.Thus,\n\n\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.3, 'left': 1.3}
            Image:
                source: "Doc/integfrac5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.123, 'left': 1.123}
            Image:
                source: "Doc/integfrac6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nCase 2:\nP sub n(x) = A is a constant and Q sub m(x) can be factorized into the form Q sub 2(x) = (x - a)(x - b),Q sub 3(x) = (x - a)(x - b)(x - c), or Q sub m(x) = (x - a sub 1)(x - a sub 2)...(x - a sub m).\n\nExample:')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.8, 'left': 0.8}
            Image:
                source: "Doc/integfrac7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nSince A/(x-3) + B/(x+1) = 1/(x-3)(x+1) implies that A(x + 1) + B(x - 3) = 1. Setting x = 3 in this equation, we obtain A = 1/4. Setting x = -1, we obtain B = -1/4. Thus,')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.64, 'left': 0.64}
            Image:
                source: "Doc/integfrac8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenintegfrac'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp5'

<ScreenElementary>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Elementary Integrals[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nAll of these follow immediately from the table of derivatives. They should be memorized.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.3, 'left': 1.3}
            Image:
                source: "Doc/elementary.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\nThe following are elementary integrals involving trigonometric functions.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.02, 'left': 1.02}
            Image:
                source: "Doc/elementary1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nThe following are elementary integrals involving hyperbolic functions.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.733, 'left': 0.733}
            Image:
                source: "Doc/elementary2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenelementary1'

<ScreenElementary1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]A selection of more complicated integrals[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\nThese begin with the two basic formulas, change of variables and integration by parts.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.15, 'left': 1.15}
            Image:
                source: "Doc/elementary3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenelementary'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp5'

<ScreenHyperbolic>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Hyperbolic Functions[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n[b]Definition:[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\nThe most frequently used hyperbolic functions are defined by,')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.353, 'left': 1.353}
            Image:
                source: "Doc/hyperbolic.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\nwhere sinh x and tanh x are odd like si x and tan x, while cosh x is even like cos x (see Fig. 4 for plots of these functions). The definitions of other hyperbolic functions are identical to the corresponding trig functions.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.073, 'left': 1.073}
            Image:
                source: "Doc/hyperbolic1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nWe can easily derive all the corresponding identites for hyperbolic functions by using the definition. However, it helps us memorize these identites if we know the relationship between sinh x, cosh x and sin x, cos x in complex analysis.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': .73, 'left': 0.73}
            Image:
                source: "Doc/hyperbolic2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp5'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenhyperbolic1'

<ScreenHyperbolic1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.4, 'left': 1.4}
            Image:
                source: "Doc/hyperbolic3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenhyperbolic'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp5'

<ScreenPreexercise>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Exercises for Pre-calculus[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n[b]Under the Function discussion:[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n1. If a function f is given by the formula y = f(x), then f(a) is the ____________ of f at x = a.\n\n2. For a function f, the set of all possible inputs is called the __________ of f, and the set of all possible outputs is called the ___________ of f.\n\n3. Which of the following functions have 5 in their domain?')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.133, 'left': 1.133}
            Image:
                source: "Doc/precalculus.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n4-7 Express the rule in function notation. (For example, the rule \'\'square, then subtract 5\'\' is expressed as the function f(x) = x^2 - 5.)\n\n5. Add 3, then multiply by 2\n6. Divide by 7, then subtract 4\n7. Subtract 5, then square\n8. Take the square root, add 8, then multiply by 1/3\n\n9. Enumerate the 4 ways to represent the function and give an example for each enumerated way.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Under the Polynomial and Rational Functions[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n1. To put the quadratic function f(x) = ax^2 + bx + c in standard form, we complete the __________.\n\n2.The quadratic function f(x) = a(x - h)^2 + k is in standard form.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpreexercise1'

<ScreenPreexercise1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('(a) The graph of f is a parabola with vertex (____, ____).\n(b) If a > 0, the graph of f opens _______. In this case f(h) = k is the ________ value of f.\n(c) If a < 0, the graph of f opens ________. In this case f(h) = k is the ________ value of f.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n3. The graph f(x) = 2(x - 3)^2 + 5 is a parabola that opens ________, with its vertex at (______, ______), and f(3) = ______ is the (minimum/maximum)________ value of f.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n[b]Under the Exponential and Logarithmic Functions[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n1. The function f(x) = 5^x is an exponential function with base _________; f(-2) = ________, f(0) = ________, f(2) = ________, and f(6) = _______.\n\n2. Match the exponential function with its graph.\n(a) f(x) = 2^x\n(b) f(x) = 2^-x\n(c) f(x) = -2^x\n(d) f(x) = -2^-x')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.78, 'left': 0.78}
            Image:
                source: "Doc/precalculus1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpreexercise'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpreexercise2'

<ScreenPreexercise2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Under the Analytic Geometry[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n1. An equation is called an identity if it is valid for _______ values of the variable. The equation 2x = x + x is an algebraic identity, and the equation sin^2x + cos^2x = ________ is a trigonometric identity.\n\n2. For any x it is true that cos(-x) has the same value as cos x. We express this fact as the identity ________.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n3-12. Write the trigonometric expression in terms of sine and cosine, and then simplify.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.06, 'left': 1.06}
            Image:
                source: "Doc/precalculus2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n13-18. Simplify the trigonometric expressions.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.77, 'left': 0.77}
            Image:
                source: "Doc/precalculus3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpreexercise1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpreexercise3'

<ScreenPreexercise3>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Under the Conic Section[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n1. A parabola is the set of all points in the plane that are equidistant from a fixed point called the _______ and a fixed line called the ________ of the parabola.\n\n2. The graph of the equation x^2 = 4py is a parabola with focus F(___, ___) and directrix y = ______. So the graph of x^2 = 12y is a parabola with focus F(___, ___) and directrix y = _____.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n3. The graph of the equation y^2 = 4px is a parabola with focus F(___, ___) and directrix x = _____. So the graph of y^2 = 12x is a parabola with focus F(___, ___) and directrix x = ________.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n4. Label the focus, directrix, and vertex on the graphs given for the parabolas in Exercise 2 and 3.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.89, 'left': 0.89}
            Image:
                source: "Doc/precalculus4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenpreexercise2'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp1'

<ScreenBasicexercise>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Basic Calculus Exercises[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n[b]Under the limit discussion[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\nFor each of the following, find the limit if it exists.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.24, 'left': 1.24}
            Image:
                source: "Doc/basicexercise.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.05, 'left': 1.05}
            Image:
                source: "Doc/basicexercise1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.843, 'left': 0.843}
            Image:
                source: "Doc/basicexercise2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp6'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenbasicexercise1'

<ScreenBasicexercise1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Under the Continuous Functions discussion[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.375, 'left': 1.375}
            Image:
                source: "Doc/basicexercise3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n[b]Under the Rules of Differentiation discussion[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\nFor each of the following y, find dy/dx.')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.1, 'left': 1.1}
            Image:
                source: "Doc/basicexercise4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Under the Angles and Trigonometric Functions discussion[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.834, 'left': 0.834}
            Image:
                source: "Doc/basicexercise5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenbasicexercise'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screenbasicexercise2'

<ScreenBasicexercise2>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]\nUnder the Differentiation of Trigonometric Functions discussion[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.32, 'left': 1.32}
            Image:
                source: "Doc/basicexercise6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenbasicexercise1'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp6'

<ScreenDiffexercise>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Differential Calculus Exercises[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n[b]Under the Calculating Gradient discussion[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.38, 'left': 1.38}
            Image:
                source: "Doc/diffexercise.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n[b]Under the Definition of Derivative discussion[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.28, 'left': 1.28}
            Image:
                source: "Doc/diffexercise1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n[b]Under the Notation of Derivative discussion[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.14, 'left': 1.14}
            Image:
                source: "Doc/diffexercise2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Under the Properties of Derivative discussion[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1, 'left': 1}
            Image:
                source: "Doc/diffexercise3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Under the Product, Chain and Quotient Rule discussion[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.86, 'left': 0.86}
            Image:
                source: "Doc/diffexercise4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.723, 'left': 0.723}
            Image:
                source: "Doc/diffexercise5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp7'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Next"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'left'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffexercise1'

<ScreenDiffexercise1>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('\n[b]Under the Tangent Line to a Graph discussion[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.412, 'left': 1.412}
            Image:
                source: "Doc/diffexercise6.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n[b]Under the Differentiation of Inverses discussion[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.3, 'left': 1.3}
            Image:
                source: "Doc/diffexercise7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n[b]Under the Implicit Differentiation discussion[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.185, 'left': 1.185}
            Image:
                source: "Doc/diffexercise8.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Previous"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screendiffexercise'

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.82, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp7'

<ScreenIntegexercise>:
    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        ScrollView:
            Label:
                text: str ('[b]Integral Calculus Exercises[b]')
                halign: 'left'
                font_size: 24
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        ScrollView:
            Label:
                text: str ('\n\n[b]Under the Fundamental Theorem discussion[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.38, 'left': 1.38}
            Image:
                source: "Doc/fundaterms7.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n[b]Under the Integration by Substitution discussion[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.28, 'left': 1.28}
            Image:
                source: "Doc/integexercise.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.23, 'left': 1.23}
            Image:
                source: "Doc/integexercise1.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n[b]Under the Integration by Parts discussion[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.138, 'left': 1.138}
            Image:
                source: "Doc/integexercise2.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 1.07, 'left': 1.07}
            Image:
                source: "Doc/integexercise3.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        ScrollView:
            Label:
                text: str ('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[b]Under the Integration by Partial Fractions discussion[b]')
                halign: 'left'
                font_size: 16
                text_size: self.width, None
                size_hint_y: None
                height: self.texture_size[1]
                
                markup: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.97, 'left': 0.97}
            Image:
                source: "Doc/integexercise4.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

        GridLayout:
            rows: 4
            col: 1
            pos_hint: {'top': 0.9, 'left': 0.9}
            Image:
                source: "Doc/integexercise5.png"
                image_size: self.width, self.texture.height
                pos_hint: {'x': 0, 'y': -0.1}
                keep_data: True

    FloatLayout:
        orientation: "vertical"
        padding: root.width * .02, root.height * .05
        spacing: min(root.width, root.height) * .02

        Button:
            size_hint: 0.15, 0.05
            pos_hint: {'x': 0.03, 'y': 0.03}
            text: "Back"
            font_size: 12
            color: 0.3, 0.6, 0.7, 1
            background_color: (0.3, 0.4, 0.5, 1)
            on_press:
                root.manager.transition.direction = 'right'
                root.manager.transition.duration = 1
                root.manager.current = 'screenp5'    
         
<Manager>:
    id: screen_manager

    screen_main: screen_main
    screen_choices: screen_choices
    screen_two: screen_two
    screen_three: screen_three
    screen_precalcov: screen_precalcov
    screen_pre2: screen_pre2
    screen_pre3: screen_pre3
    screen_pre4: screen_pre4
    screen_pre5: screen_pre5
    screen_pre6: screen_pre6
    screen_pre7: screen_pre7
    screen_realnum: screen_realnum
    screen_realnum1: screen_realnum1
    screen_realnum2: screen_realnum2
    screen_realnum3: screen_realnum3
    screen_realnum4: screen_realnum4
    screen_intexp: screen_intexp
    screen_intexp1: screen_intexp1
    screen_intexp2: screen_intexp2
    screen_rad: screen_rad
    screen_rad1: screen_rad1
    screen_ratio: screen_ratio
    screen_ratio1: screen_ratio1
    screen_ratio2: screen_ratio2
    screen_ratio3: screen_ratio3
    screen_ratio4: screen_ratio4
    screen_ratio5: screen_ratio5
    screen_ratio6: screen_ratio6
    screen_ratio7: screen_ratio7
    screen_alg: screen_alg
    screen_alg1: screen_alg1
    screen_alg2: screen_alg2
    screen_alg3: screen_alg3
    screen_alg4: screen_alg4
    screen_alg5: screen_alg5
    screen_alg6: screen_alg6
    screen_alg7: screen_alg7
    screen_equate: screen_equate
    screen_equate1: screen_equate1
    screen_equate2: screen_equate2
    screen_equate3: screen_equate3
    screen_equate4: screen_equate4
    screen_equate5: screen_equate5
    screen_equate6: screen_equate6
    screen_function: screen_function
    screen_function1: screen_function1
    screen_function2: screen_function2
    screen_function3: screen_function3
    screen_function4: screen_function4
    screen_function5: screen_function5
    screen_function6: screen_function6
    screen_poly: screen_poly
    screen_poly1: screen_poly1
    screen_poly2: screen_poly2
    screen_poly3: screen_poly3
    screen_poly4: screen_poly4
    screen_poly5: screen_poly5
    screen_poly6: screen_poly6
    screen_poly7: screen_poly7
    screen_poly8: screen_poly8
    screen_poly9: screen_poly9
    screen_expo: screen_expo
    screen_expo1: screen_expo1
    screen_expo2: screen_expo2
    screen_expo3: screen_expo3
    screen_expo4: screen_expo4
    screen_expo5: screen_expo5
    screen_algo: screen_algo
    screen_algo1: screen_algo1
    screen_algo2: screen_algo2
    screen_algo3: screen_algo3
    screen_algo4: screen_algo4
    screen_algo5: screen_algo5
    screen_algo6: screen_algo6
    screen_algo7: screen_algo7
    screen_unit: screen_unit
    screen_unit1: screen_unit1
    screen_unit2: screen_unit2
    screen_unit3: screen_unit3
    screen_unit4: screen_unit4
    screen_unit5: screen_unit5
    screen_geo: screen_geo
    screen_geo1: screen_geo1
    screen_geo2: screen_geo2
    screen_geo3: screen_geo3
    screen_geo4: screen_geo4
    screen_geo5: screen_geo5
    screen_conic: screen_conic
    screen_conic1: screen_conic1
    screen_conic2: screen_conic2
    screen_conic3: screen_conic3
    screen_conic4: screen_conic4
    screen_conic5: screen_conic5
    screen_conic6: screen_conic6
    screen_conic7: screen_conic7
    screen_conic8: screen_conic8
    screen_conic9: screen_conic9
    screen_conic10: screen_conic10
    screen_conic11: screen_conic11
    screen_conic12: screen_conic12
    screen_conic13: screen_conic13
    screen_conic14: screen_conic14
    screen_conic15: screen_conic15
    screen_conic16: screen_conic16
    screen_conic17: screen_conic17
    screen_conic18: screen_conic18
    screen_conic19: screen_conic19
    screen_conic20: screen_conic20
    screen_conic21: screen_conic21
    screen_conic22: screen_conic22
    screen_intro: screen_intro
    screen_intro1: screen_intro1
    screen_intro2: screen_intro2
    screen_intro3: screen_intro3
    screen_intro4: screen_intro4
    screen_intro5: screen_intro5
    screen_limit: screen_limit
    screen_limit1: screen_limit1
    screen_limit2: screen_limit2
    screen_limit3: screen_limit3
    screen_limit4: screen_limit4
    screen_limit5: screen_limit5
    screen_limit6: screen_limit6
    screen_limit7: screen_limit7
    screen_twolimit: screen_twolimit
    screen_twolimit1: screen_twolimit1
    screen_twolimit2: screen_twolimit2
    screen_twolimit3: screen_twolimit3
    screen_continue: screen_continue
    screen_continue1: screen_continue1
    screen_continue2: screen_continue2
    screen_continue3: screen_continue3
    screen_continue4: screen_continue4
    screen_derivatives: screen_derivatives
    screen_derivatives1: screen_derivatives1
    screen_derivatives2: screen_derivatives2
    screen_derivatives3: screen_derivatives3
    screen_derivatives4: screen_derivatives4
    screen_diffrules: screen_diffrules
    screen_diffrules1: screen_diffrules1
    screen_diffrules2: screen_diffrules2
    screen_diffrules3: screen_diffrules3
    screen_diffrules4: screen_diffrules4
    screen_diffrules5: screen_diffrules5
    screen_diffrules6: screen_diffrules6
    screen_diffrules7: screen_diffrules7
    screen_diffrules8: screen_diffrules8
    screen_diffrules9: screen_diffrules9
    screen_chainrule: screen_chainrule
    screen_chainrule1: screen_chainrule1
    screen_chainrule2: screen_chainrule2
    screen_chainrule3: screen_chainrule3
    screen_chainrule4: screen_chainrule4
    screen_chainrule5: screen_chainrule5
    screen_angles: screen_angles
    screen_angles1: screen_angles1
    screen_angles2: screen_angles2
    screen_angles3: screen_angles3
    screen_angles4: screen_angles4
    screen_angles5: screen_angles5
    screen_angles6: screen_angles6
    screen_angles7: screen_angles7
    screen_difftrigo: screen_difftrigo
    screen_difftrigo1: screen_difftrigo1
    screen_difftrigo2: screen_difftrigo2
    screen_gradient: screen_gradient
    screen_gradient1: screen_gradient1
    screen_gradient2: screen_gradient2
    screen_cgradient: screen_cgradient
    screen_cgradient1: screen_cgradient1
    screen_cgradient2: screen_cgradient2
    screen_defderivative: screen_defderivative
    screen_defderivative1: screen_defderivative1
    screen_notation: screen_notation
    screen_notation1: screen_notation1
    screen_properties: screen_properties
    screen_properties1: screen_properties1
    screen_properties2: screen_properties2
    screen_properties3: screen_properties3
    screen_summary: screen_summary
    screen_tangent: screen_tangent
    screen_secderivative: screen_secderivative
    screen_secderivative1: screen_secderivative1
    screen_inverse: screen_inverse
    screen_inverse1: screen_inverse1
    screen_implicit: screen_implicit
    screen_implicit1: screen_implicit1
    screen_implicit2: screen_implicit2
    screen_prochain: screen_prochain
    screen_prochain1: screen_prochain1
    screen_prochain2: screen_prochain2
    screen_prochain3: screen_prochain3
    screen_prochain4: screen_prochain4
    screen_prochain5: screen_prochain5
    screen_prochain6: screen_prochain6
    screen_prochain7: screen_prochain7
    screen_about: screen_about
    screen_fundaterms: screen_fundaterms
    screen_fundaterms1: screen_fundaterms1
    screen_substitution: screen_substitution
    screen_substitution1: screen_substitution1
    screen_integparts: screen_integparts
    screen_integparts1: screen_integparts1
    screen_integfrac: screen_integfrac
    screen_integfrac1: screen_integfrac1
    screen_elementary: screen_elementary
    screen_elementary1: screen_elementary1
    screen_hyperbolic: screen_hyperbolic
    screen_hyperbolic1: screen_hyperbolic1
    screen_preexercise: screen_preexercise
    screen_preexercise1: screen_preexercise1
    screen_preexercise2: screen_preexercise2
    screen_preexercise3: screen_preexercise3
    screen_basicexercise: screen_basicexercise
    screen_basicexercise1: screen_basicexercise
    screen_basicexercise2: screen_basicexercise
    screen_diffexercise: screen_diffexercise
    screen_diffexercise1: screen_diffexercise1
    screen_integexercise: screen_integexercise
    screen_pop: screen_pop
    screen_pop1: screen_pop1
    screen_pop2: screen_pop2
    screen_pop3: screen_pop3
    screen_pop4: screen_pop4
    screen_pop5: screen_pop5
    screen_pop6: screen_pop6
    screen_pop6: screen_pop6
    screen_pop7: screen_pop7
    
    ScreenMain:
        id: screen_main
        name: 'screenmain'
        manager: screen_manager

    ScreenChoices:
        id: screen_choices
        name: 'screen1'
        manager: screen_manager

    ScreenTwo:
        id: screen_two
        name: 'screen2'
        manager: screen_manager

    ScreenThree:
        id: screen_three
        name: 'screen3'
        manager: screen_manager

    ScreenPrecalcov:
        id: screen_precalcov
        name: 'screenp1'
        manager: screen_manager

    ScreenPre2:
        id: screen_pre2
        name: 'screenp2'
        manager: screen_manager

    ScreenPre3:
        id: screen_pre3
        name: 'screenp3'
        manager: screen_manager

    ScreenPre4:
        id: screen_pre4
        name: 'screenp4'
        manager: screen_manager

    ScreenPre5:
        id: screen_pre5
        name: 'screenp5'
        manager: screen_manager

    ScreenPre6:
        id: screen_pre6
        name: 'screenp6'
        manager: screen_manager

    ScreenPre7:
        id: screen_pre7
        name: 'screenp7'
        manager: screen_manager

    Screen_Realnum:
        id: screen_realnum
        name: 'screen_realnum'
        manager: screen_manager

    Screen_Realnum1:
        id: screen_realnum1
        name: 'screen_realnum1'
        manager: screen_manager

    Screen_Realnum2:
        id: screen_realnum2
        name: 'screen_realnum2'
        manager: screen_manager

    Screen_Realnum3:
        id: screen_realnum3
        name: 'screen_realnum3'
        manager: screen_manager

    Screen_Realnum4:
        id: screen_realnum4
        name: 'screen_realnum4'
        manager: screen_manager

    Screen_Intexp:
        id: screen_intexp
        name: 'screen_intexp'
        manager: screen_manager

    Screen_Intexp1:
        id: screen_intexp1
        name: 'screen_intexp1'
        manager: screen_manager

    Screen_Intexp2:
        id: screen_intexp2
        name: 'screen_intexp2'
        manager: screen_manager

    Screen_Rad:
        id: screen_rad
        name: 'screen_rad'
        manager: screen_manager

    Screen_Rad1:
        id: screen_rad1
        name: 'screen_rad1'
        manager: screen_manager

    ScreenRatio:
        id: screen_ratio
        name: 'screenratio'
        manager: screen_manager

    ScreenRatio1:
        id: screen_ratio1
        name: 'screenratio1'
        manager: screen_manager

    ScreenRatio2:
        id: screen_ratio2
        name: 'screenratio2'
        manager: screen_manager

    ScreenRatio3:
        id: screen_ratio3
        name: 'screenratio3'
        manager: screen_manager

    ScreenRatio4:
        id: screen_ratio4
        name: 'screenratio4'
        manager: screen_manager

    ScreenRatio5:
        id: screen_ratio5
        name: 'screenratio5'
        manager: screen_manager

    ScreenRatio6:
        id: screen_ratio6
        name: 'screenratio6'
        manager: screen_manager

    ScreenRatio7:
        id: screen_ratio7
        name: 'screenratio7'
        manager: screen_manager

    ScreenAlg:
        id: screen_alg
        name: 'screenalg'
        manager: screen_manager

    ScreenAlg1:
        id: screen_alg1
        name: 'screenalg1'
        manager: screen_manager

    ScreenAlg2:
        id: screen_alg2
        name: 'screenalg2'
        manager: screen_manager

    ScreenAlg3:
        id: screen_alg3
        name: 'screenalg3'
        manager: screen_manager

    ScreenAlg4:
        id: screen_alg4
        name: 'screenalg4'
        manager: screen_manager

    ScreenAlg5:
        id: screen_alg5
        name: 'screenalg5'
        manager: screen_manager

    ScreenAlg6:
        id: screen_alg6
        name: 'screenalg6'
        manager: screen_manager

    ScreenAlg7:
        id: screen_alg7
        name: 'screenalg7'
        manager: screen_manager
        
    ScreenEquate:
        id: screen_equate
        name: 'screenequate'
        manager: screen_manager

    ScreenEquate1:
        id: screen_equate1
        name: 'screenequate1'
        manager: screen_manager

    ScreenEquate2:
        id: screen_equate2
        name: 'screenequate2'
        manager: screen_manager

    ScreenEquate3:
        id: screen_equate3
        name: 'screenequate3'
        manager: screen_manager

    ScreenEquate4:
        id: screen_equate4
        name: 'screenequate4'
        manager: screen_manager

    ScreenEquate5:
        id: screen_equate5
        name: 'screenequate5'
        manager: screen_manager

    ScreenEquate6:
        id: screen_equate6
        name: 'screenequate6'
        manager: screen_manager

    ScreenFunction:
        id: screen_function
        name: 'screenfunction'
        manager: screen_manager

    ScreenFunction1:
        id: screen_function1
        name: 'screenfunction1'
        manager: screen_manager

    ScreenFunction2:
        id: screen_function2
        name: 'screenfunction2'
        manager: screen_manager

    ScreenFunction3:
        id: screen_function3
        name: 'screenfunction3'
        manager: screen_manager

    ScreenFunction4:
        id: screen_function4
        name: 'screenfunction4'
        manager: screen_manager

    ScreenFunction5:
        id: screen_function5
        name: 'screenfunction5'
        manager: screen_manager

    ScreenFunction6:
        id: screen_function6
        name: 'screenfunction6'
        manager: screen_manager

    ScreenPoly:
        id: screen_poly
        name: 'screenpoly'
        manager: screen_manager

    ScreenPoly1:
        id: screen_poly1
        name: 'screenpoly1'
        manager: screen_manager

    ScreenPoly2:
        id: screen_poly2
        name: 'screenpoly2'
        manager: screen_manager

    ScreenPoly3:
        id: screen_poly3
        name: 'screenpoly3'
        manager: screen_manager

    ScreenPoly4:
        id: screen_poly4
        name: 'screenpoly4'
        manager: screen_manager

    ScreenPoly5:
        id: screen_poly5
        name: 'screenpoly5'
        manager: screen_manager

    ScreenPoly6:
        id: screen_poly6
        name: 'screenpoly6'
        manager: screen_manager

    ScreenPoly7:
        id: screen_poly7
        name: 'screenpoly7'
        manager: screen_manager

    ScreenPoly8:
        id: screen_poly8
        name: 'screenpoly8'
        manager: screen_manager

    ScreenPoly9:
        id: screen_poly9
        name: 'screenpoly9'
        manager: screen_manager

    ScreenExpo:
        id: screen_expo
        name: 'screenexpo'
        manager: screen_manager

    ScreenExpo1:
        id: screen_expo1
        name: 'screenexpo1'
        manager: screen_manager

    ScreenExpo2:
        id: screen_expo2
        name: 'screenexpo2'
        manager: screen_manager

    ScreenExpo3:
        id: screen_expo3
        name: 'screenexpo3'
        manager: screen_manager

    ScreenExpo4:
        id: screen_expo4
        name: 'screenexpo4'
        manager: screen_manager

    ScreenExpo5:
        id: screen_expo5
        name: 'screenexpo5'
        manager: screen_manager

    ScreenAlgo:
        id: screen_algo
        name: 'screenalgo'
        manager: screen_manager

    ScreenAlgo1:
        id: screen_algo1
        name: 'screenalgo1'
        manager: screen_manager

    ScreenAlgo2:
        id: screen_algo2
        name: 'screenalgo2'
        manager: screen_manager

    ScreenAlgo3:
        id: screen_algo3
        name: 'screenalgo3'
        manager: screen_manager

    ScreenAlgo4:
        id: screen_algo4
        name: 'screenalgo4'
        manager: screen_manager

    ScreenAlgo5:
        id: screen_algo5
        name: 'screenalgo5'
        manager: screen_manager

    ScreenAlgo6:
        id: screen_algo6
        name: 'screenalgo6'
        manager: screen_manager

    ScreenAlgo7:
        id: screen_algo7
        name: 'screenalgo7'
        manager: screen_manager

    ScreenUnit:
        id: screen_unit
        name: 'screenunit'
        manager: screen_manager

    ScreenUnit1:
        id: screen_unit1
        name: 'screenunit1'
        manager: screen_manager

    ScreenUnit2:
        id: screen_unit2
        name: 'screenunit2'
        manager: screen_manager

    ScreenUnit3:
        id: screen_unit3
        name: 'screenunit3'
        manager: screen_manager

    ScreenUnit4:
        id: screen_unit4
        name: 'screenunit4'
        manager: screen_manager

    ScreenUnit5:
        id: screen_unit5
        name: 'screenunit5'
        manager: screen_manager

    ScreenGeo:
        id: screen_geo
        name: 'screengeo'
        manager: screen_manager

    ScreenGeo1:
        id: screen_geo1
        name: 'screengeo1'
        manager: screen_manager

    ScreenGeo2:
        id: screen_geo2
        name: 'screengeo2'
        manager: screen_manager

    ScreenGeo3:
        id: screen_geo3
        name: 'screengeo3'
        manager: screen_manager

    ScreenGeo4:
        id: screen_geo4
        name: 'screengeo4'
        manager: screen_manager

    ScreenGeo5:
        id: screen_geo5
        name: 'screengeo5'
        manager: screen_manager

    ScreenConic:
        id: screen_conic
        name: 'screenconic'
        manager: screen_manager

    ScreenConic1:
        id: screen_conic1
        name: 'screenconic1'
        manager: screen_manager

    ScreenConic2:
        id: screen_conic2
        name: 'screenconic2'
        manager: screen_manager

    ScreenConic3:
        id: screen_conic3
        name: 'screenconic3'
        manager: screen_manager

    ScreenConic4:
        id: screen_conic4
        name: 'screenconic4'
        manager: screen_manager

    ScreenConic5:
        id: screen_conic5
        name: 'screenconic5'
        manager: screen_manager

    ScreenConic6:
        id: screen_conic6
        name: 'screenconic6'
        manager: screen_manager

    ScreenConic7:
        id: screen_conic7
        name: 'screenconic7'
        manager: screen_manager

    ScreenConic8:
        id: screen_conic8
        name: 'screenconic8'
        manager: screen_manager

    ScreenConic9:
        id: screen_conic9
        name: 'screenconic9'
        manager: screen_manager

    ScreenConic10:
        id: screen_conic10
        name: 'screenconic10'
        manager: screen_manager

    ScreenConic11:
        id: screen_conic11
        name: 'screenconic11'
        manager: screen_manager

    ScreenConic12:
        id: screen_conic12
        name: 'screenconic12'
        manager: screen_manager

    ScreenConic13:
        id: screen_conic13
        name: 'screenconic13'
        manager: screen_manager

    ScreenConic14:
        id: screen_conic14
        name: 'screenconic14'
        manager: screen_manager

    ScreenConic15:
        id: screen_conic15
        name: 'screenconic15'
        manager: screen_manager

    ScreenConic16:
        id: screen_conic16
        name: 'screenconic16'
        manager: screen_manager

    ScreenConic17:
        id: screen_conic17
        name: 'screenconic17'
        manager: screen_manager

    ScreenConic18:
        id: screen_conic18
        name: 'screenconic18'
        manager: screen_manager

    ScreenConic19:
        id: screen_conic19
        name: 'screenconic19'
        manager: screen_manager

    ScreenConic20:
        id: screen_conic20
        name: 'screenconic20'
        manager: screen_manager

    ScreenConic21:
        id: screen_conic21
        name: 'screenconic21'
        manager: screen_manager

    ScreenConic22:
        id: screen_conic22
        name: 'screenconic22'
        manager: screen_manager

    ScreenIntro:
        id: screen_intro
        name: 'screenintro'
        manager: screen_manager

    ScreenIntro1:
        id: screen_intro1
        name: 'screenintro1'
        manager: screen_manager

    ScreenIntro2:
        id: screen_intro2
        name: 'screenintro2'
        manager: screen_manager

    ScreenIntro3:
        id: screen_intro3
        name: 'screenintro3'
        manager: screen_manager

    ScreenIntro4:
        id: screen_intro4
        name: 'screenintro4'
        manager: screen_manager

    ScreenIntro5:
        id: screen_intro5
        name: 'screenintro5'
        manager: screen_manager

    ScreenLimit:
        id: screen_limit
        name: 'screenlimit'
        manager: screen_manager

    ScreenLimit1:
        id: screen_limit1
        name: 'screenlimit1'
        manager: screen_manager

    ScreenLimit2:
        id: screen_limit2
        name: 'screenlimit2'
        manager: screen_manager

    ScreenLimit3:
        id: screen_limit3
        name: 'screenlimit3'
        manager: screen_manager

    ScreenLimit4:
        id: screen_limit4
        name: 'screenlimit4'
        manager: screen_manager

    ScreenLimit5:
        id: screen_limit5
        name: 'screenlimit5'
        manager: screen_manager

    ScreenLimit6:
        id: screen_limit6
        name: 'screenlimit6'
        manager: screen_manager

    ScreenLimit7:
        id: screen_limit7
        name: 'screenlimit7'
        manager: screen_manager

    ScreenTwoLimit:
        id: screen_twolimit
        name: 'screentwolimit'
        manager: screen_manager

    ScreenTwoLimit1:
        id: screen_twolimit1
        name: 'screentwolimit1'
        manager: screen_manager

    ScreenTwoLimit2:
        id: screen_twolimit2
        name: 'screentwolimit2'
        manager: screen_manager

    ScreenTwoLimit3:
        id: screen_twolimit3
        name: 'screentwolimit3'
        manager: screen_manager

    ScreenContinue:
        id: screen_continue
        name: 'screencontinue'
        manager: screen_manager

    ScreenContinue1:
        id: screen_continue1
        name: 'screencontinue1'
        manager: screen_manager

    ScreenContinue2:
        id: screen_continue2
        name: 'screencontinue2'
        manager: screen_manager

    ScreenContinue3:
        id: screen_continue3
        name: 'screencontinue3'
        manager: screen_manager

    ScreenContinue4:
        id: screen_continue4
        name: 'screencontinue4'
        manager: screen_manager

    ScreenDerivatives:
        id: screen_derivatives
        name: 'screenderivatives'
        manager: screen_manager

    ScreenDerivatives1:
        id: screen_derivatives1
        name: 'screenderivatives1'
        manager: screen_manager

    ScreenDerivatives2:
        id: screen_derivatives2
        name: 'screenderivatives2'
        manager: screen_manager

    ScreenDerivatives3:
        id: screen_derivatives3
        name: 'screenderivatives3'
        manager: screen_manager

    ScreenDerivatives4:
        id: screen_derivatives4
        name: 'screenderivatives4'
        manager: screen_manager

    ScreenDiffrules:
        id: screen_diffrules
        name: 'screendiffrules'
        manager: screen_manager

    ScreenDiffrules1:
        id: screen_diffrules1
        name: 'screendiffrules1'
        manager: screen_manager

    ScreenDiffrules2:
        id: screen_diffrules2
        name: 'screendiffrules2'
        manager: screen_manager

    ScreenDiffrules3:
        id: screen_diffrules3
        name: 'screendiffrules3'
        manager: screen_manager

    ScreenDiffrules4:
        id: screen_diffrules4
        name: 'screendiffrules4'
        manager: screen_manager

    ScreenDiffrules5:
        id: screen_diffrules5
        name: 'screendiffrules5'
        manager: screen_manager

    ScreenDiffrules6:
        id: screen_diffrules6
        name: 'screendiffrules6'
        manager: screen_manager

    ScreenDiffrules7:
        id: screen_diffrules7
        name: 'screendiffrules7'
        manager: screen_manager

    ScreenDiffrules8:
        id: screen_diffrules8
        name: 'screendiffrules8'
        manager: screen_manager

    ScreenDiffrules9:
        id: screen_diffrules9
        name: 'screendiffrules9'
        manager: screen_manager

    ScreenChainrule:
        id: screen_chainrule
        name: 'screenchainrule'
        manager: screen_manager

    ScreenChainrule1:
        id: screen_chainrule1
        name: 'screenchainrule1'
        manager: screen_manager

    ScreenChainrule2:
        id: screen_chainrule2
        name: 'screenchainrule2'
        manager: screen_manager

    ScreenChainrule3:
        id: screen_chainrule3
        name: 'screenchainrule3'
        manager: screen_manager

    ScreenChainrule4:
        id: screen_chainrule4
        name: 'screenchainrule4'
        manager: screen_manager

    ScreenChainrule5:
        id: screen_chainrule5
        name: 'screenchainrule5'
        manager: screen_manager

    ScreenAngles:
        id: screen_angles
        name: 'screenangles'
        manager: screen_manager

    ScreenAngles1:
        id: screen_angles1
        name: 'screenangles1'
        manager: screen_manager

    ScreenAngles2:
        id: screen_angles2
        name: 'screenangles2'
        manager: screen_manager

    ScreenAngles3:
        id: screen_angles3
        name: 'screenangles3'
        manager: screen_manager

    ScreenAngles4:
        id: screen_angles4
        name: 'screenangles4'
        manager: screen_manager

    ScreenAngles5:
        id: screen_angles5
        name: 'screenangles5'
        manager: screen_manager

    ScreenAngles6:
        id: screen_angles6
        name: 'screenangles6'
        manager: screen_manager

    ScreenAngles7:
        id: screen_angles7
        name: 'screenangles7'
        manager: screen_manager

    ScreenDifftrigo:
        id: screen_difftrigo
        name: 'screendifftrigo'
        manager: screen_manager

    ScreenDifftrigo1:
        id: screen_difftrigo1
        name: 'screendifftrigo1'
        manager: screen_manager

    ScreenDifftrigo2:
        id: screen_difftrigo2
        name: 'screendifftrigo2'
        manager: screen_manager

    ScreenGradient:
        id: screen_gradient
        name: 'screengradient'
        manager: screen_manager

    ScreenGradient1:
        id: screen_gradient1
        name: 'screengradient1'
        manager: screen_manager

    ScreenGradient2:
        id: screen_gradient2
        name: 'screengradient2'
        manager: screen_manager

    ScreenCgradient:
        id: screen_cgradient
        name: 'screencgradient'
        manager: screen_manager

    ScreenCgradient1:
        id: screen_cgradient1
        name: 'screencgradient1'
        manager: screen_manager

    ScreenCgradient2:
        id: screen_cgradient2
        name: 'screencgradient2'
        manager: screen_manager

    ScreenDefderivative:
        id: screen_defderivative
        name: 'screendefderivative'
        manager: screen_manager

    ScreenDefderivative1:
        id: screen_defderivative1
        name: 'screendefderivative1'
        manager: screen_manager

    ScreenNotation:
        id: screen_notation
        name: 'screennotation'
        manager: screen_manager

    ScreenNotation1:
        id: screen_notation1
        name: 'screennotation1'
        manager: screen_manager

    ScreenProperties:
        id: screen_properties
        name: 'screenproperties'
        manager: screen_manager

    ScreenProperties1:
        id: screen_properties1
        name: 'screenproperties1'
        manager: screen_manager

    ScreenProperties2:
        id: screen_properties2
        name: 'screenproperties2'
        manager: screen_manager

    ScreenProperties3:
        id: screen_properties3
        name: 'screenproperties3'
        manager: screen_manager

    ScreenSummary:
        id: screen_summary
        name: 'screensummary'
        manager: screen_manager

    ScreenTangent:
        id: screen_tangent
        name: 'screentangent'
        manager: screen_manager

    ScreenSecderivative:
        id: screen_secderivative
        name: 'screensecderivative'
        manager: screen_manager

    ScreenSecderivative1:
        id: screen_secderivative1
        name: 'screensecderivative1'
        manager: screen_manager

    ScreenInverse:
        id: screen_inverse
        name: 'screeninverse'
        manager: screen_manager

    ScreenInverse1:
        id: screen_inverse1
        name: 'screeninverse1'
        manager: screen_manager

    ScreenImplicit:
        id: screen_implicit
        name: 'screenimplicit'
        manager: screen_manager

    ScreenImplicit1:
        id: screen_implicit1
        name: 'screenimplicit1'
        manager: screen_manager

    ScreenImplicit2:
        id: screen_implicit2
        name: 'screenimplicit2'
        manager: screen_manager

    ScreenProchain:
        id: screen_prochain
        name: 'screenprochain'
        manager: screen_manager

    ScreenProchain1:
        id: screen_prochain1
        name: 'screenprochain1'
        manager: screen_manager

    ScreenProchain2:
        id: screen_prochain2
        name: 'screenprochain2'
        manager: screen_manager

    ScreenProchain3:
        id: screen_prochain3
        name: 'screenprochain3'
        manager: screen_manager

    ScreenProchain4:
        id: screen_prochain4
        name: 'screenprochain4'
        manager: screen_manager

    ScreenProchain5:
        id: screen_prochain5
        name: 'screenprochain5'
        manager: screen_manager

    ScreenProchain6:
        id: screen_prochain6
        name: 'screenprochain6'
        manager: screen_manager

    ScreenProchain7:
        id: screen_prochain7
        name: 'screenprochain7'
        manager: screen_manager

    ScreenAbout:
        id: screen_about
        name: 'screenabout'
        manager: screen_manager

    ScreenFundaterms:
        id: screen_fundaterms
        name: 'screenfundaterms'
        manager: screen_manager

    ScreenFundaterms1:
        id: screen_fundaterms1
        name: 'screenfundaterms1'
        manager: screen_manager

    ScreenSubstitution:
        id: screen_substitution
        name: 'screensubstitution'
        manager: screen_manager

    ScreenSubstitution1:
        id: screen_substitution1
        name: 'screensubstitution1'
        manager: screen_manager

    ScreenIntegparts:
        id: screen_integparts
        name: 'screenintegparts'
        manager: screen_manager

    ScreenIntegparts1:
        id: screen_integparts1
        name: 'screenintegparts1'
        manager: screen_manager

    ScreenIntegfrac:
        id: screen_integfrac
        name: 'screenintegfrac'
        manager: screen_manager

    ScreenIntegfrac1:
        id: screen_integfrac1
        name: 'screenintegfrac1'
        manager: screen_manager

    ScreenElementary:
        id: screen_elementary
        name: 'screenelementary'
        manager: screen_manager

    ScreenElementary1:
        id: screen_elementary1
        name: 'screenelementary1'
        manager: screen_manager

    ScreenHyperbolic:
        id: screen_hyperbolic
        name: 'screenhyperbolic'
        manager: screen_manager

    ScreenHyperbolic1:
        id: screen_hyperbolic1
        name: 'screenhyperbolic1'
        manager: screen_manager

    ScreenPreexercise:
        id: screen_preexercise
        name: 'screenpreexercise'
        manager: screen_manager

    ScreenPreexercise1:
        id: screen_preexercise1
        name: 'screenpreexercise1'
        manager: screen_manager

    ScreenPreexercise2:
        id: screen_preexercise2
        name: 'screenpreexercise2'
        manager: screen_manager

    ScreenPreexercise3:
        id: screen_preexercise3
        name: 'screenpreexercise3'
        manager: screen_manager

    ScreenBasicexercise:
        id: screen_basicexercise
        name: 'screenbasicexercise'
        manager: screen_manager

    ScreenBasicexercise1:
        id: screen_basicexercise1
        name: 'screenbasicexercise1'
        manager: screen_manager

    ScreenBasicexercise2:
        id: screen_basicexercise2
        name: 'screenbasicexercise2'
        manager: screen_manager

    ScreenDiffexercise:
        id: screen_diffexercise
        name: 'screendiffexercise'
        manager: screen_manager

    ScreenDiffexercise1:
        id: screen_diffexercise1
        name: 'screendiffexercise1'
        manager: screen_manager

    ScreenIntegexercise:
        id: screen_integexercise
        name: 'screenintegexercise'
        manager: screen_manager

    ScreenPop:
        id: screen_pop
        name: 'screenpop'
        manager: screen_manager

    ScreenPop1:
        id: screen_pop1
        name: 'screenpop1'
        manager: screen_manager

    ScreenPop2:
        id: screen_pop2
        name: 'screenpop2'
        manager: screen_manager

    ScreenPop3:
        id: screen_pop3
        name: 'screenpop3'
        manager: screen_manager

    ScreenPop4:
        id: screen_pop4
        name: 'screenpop4'
        manager: screen_manager

    ScreenPop5:
        id: screen_pop5
        name: 'screenpop5'
        manager: screen_manager

    ScreenPop6:
        id: screen_pop6
        name: 'screenpop6'
        manager: screen_manager

    ScreenPop7:
        id: screen_pop7
        name: 'screenpop7'
        manager: screen_manager
